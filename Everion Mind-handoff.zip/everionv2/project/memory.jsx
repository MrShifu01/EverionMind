/* Memory grid + Timeline + Entry detail */

function EntryCard({ entry, selected, onSelect, onOpen, density = 'cozy' }) {
  const [hover, setHover] = React.useState(false);
  const pad = density === 'compact' ? 16 : 20;
  return <div className="card press" onClick={() => onOpen(entry)}
    onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
    style={{
      padding: pad, position:'relative', cursor:'pointer',
      borderLeft: entry.pinned ? '2px solid var(--ember)' : '1px solid var(--line-soft)',
      background: selected ? 'var(--ember-wash)' : (entry.pinned ? 'var(--surface-high)' : undefined),
      borderColor: selected ? 'var(--ember)' : undefined,
    }}>
    <div className="row gap-2" style={{ marginBottom: 10, color:'var(--ink-faint)' }}>
      <TypeGlyph type={entry.type} size={13}/>
      <span className="f-sans" style={{ fontSize: 12, textTransform:'uppercase', letterSpacing:'0.04em' }}>{entry.type}</span>
      <span className="f-sans" style={{ fontSize: 12, marginLeft:'auto' }}>{relTime(entry.created)}</span>
      {entry.pinned && <I.pin style={{ width: 12, height: 12, color:'var(--ember)' }}/>}
      {entry.vault && <I.vault style={{ width: 12, height: 12, color:'var(--ink-faint)' }}/>}
    </div>
    <h3 className="f-serif" style={{ fontSize: 18, lineHeight: 1.25, fontWeight: 450, margin: 0, letterSpacing:'-0.005em' }}>
      {entry.title}
    </h3>
    <p className="f-serif clip-3" style={{ fontSize: 15, lineHeight: 1.55, color:'var(--ink-soft)', margin:'8px 0 14px' }}>
      {entry.body}
    </p>
    <div className="row gap-1" style={{ flexWrap:'wrap' }}>
      {entry.tags.slice(0, 3).map(t => <span key={t} className="chip" style={{ height: 20, fontSize: 11, padding:'0 8px' }}>{t}</span>)}
    </div>
    {hover && <button onClick={(e) => { e.stopPropagation(); onSelect(entry.id); }}
      className="press" style={{
        position:'absolute', top: 12, right: 12, width: 20, height: 20, minHeight: 20,
        border:'1px solid var(--line)', borderRadius: 4,
        background: selected ? 'var(--ember)' : 'var(--surface-high)',
        display:'flex', alignItems:'center', justifyContent:'center',
      }}>
      {selected && <I.check style={{ width: 14, height: 14, color:'oklch(14% 0.03 50)' }}/>}
    </button>}
  </div>;
}

function MemoryGrid({ go, openEntry, density, onOmni }) {
  const [filterType, setFilterType] = React.useState('all');
  const [view, setView] = React.useState('grid'); // grid | timeline
  const [q, setQ] = React.useState('');
  const [selected, setSelected] = React.useState([]);
  const [empty, setEmpty] = React.useState(false);

  const filtered = React.useMemo(() => {
    let e = ENTRIES.filter(x => !x.vault);
    if (filterType !== 'all') e = e.filter(x => x.type === filterType);
    if (q.trim()) e = e.filter(x => (x.title + x.body + x.tags.join(' ')).toLowerCase().includes(q.toLowerCase()));
    return e.sort((a,b) => (b.pinned - a.pinned) || new Date(b.created) - new Date(a.created));
  }, [filterType, q]);

  const byDay = React.useMemo(() => {
    const m = new Map();
    filtered.forEach(e => {
      const key = e.created.slice(0,10);
      if (!m.has(key)) m.set(key, []);
      m.get(key).push(e);
    });
    return [...m.entries()];
  }, [filtered]);

  const noMatch = filtered.length === 0 && q.trim().length > 0;

  return <div style={{ height:'100%', display:'flex', flexDirection:'column' }}>
    <TopBar title="Memory" subtitle={empty ? 'nothing yet.' : `${filtered.length} entries`} onSearch={onOmni}
      right={<button className="btn-primary press" onClick={() => go('capture')}>
        <I.plus style={{ width: 14, height: 14, marginRight: 6 }}/>Remember
      </button>}/>

    {/* Controls */}
    <div className="row" style={{ padding:'14px 32px', gap: 12, borderBottom:'1px solid var(--line-soft)', flexWrap:'wrap' }}>
      <Segmented options={[{ value:'grid', label:'Grid' }, { value:'timeline', label:'Timeline' }]} value={view} onChange={setView}/>
      <div className="vr" style={{ height: 24 }}/>
      <div className="row gap-1" style={{ flexWrap:'wrap' }}>
        {['all','note','link','reminder','idea','contact','file'].map(t =>
          <Pill key={t} active={filterType === t} onClick={() => setFilterType(t)}>{t}</Pill>
        )}
      </div>
      <div style={{ flex: 1 }}/>
      <div className="row gap-2">
        <button className="btn-ghost press" style={{ fontSize: 13 }}>
          <I.sort style={{ width: 14, height: 14, marginRight: 6 }}/>Recent first
        </button>
        <button className="btn-ghost press" style={{ fontSize: 13 }} onClick={() => setEmpty(v => !v)}>
          <I.eye style={{ width: 14, height: 14, marginRight: 6 }}/>{empty ? 'Show' : 'Empty'}
        </button>
      </div>
    </div>

    {/* Body */}
    <div className="scroll" style={{ flex: 1, padding:'24px 32px', position:'relative' }}>
      {empty ? <EmptyState/> :
       noMatch ? <NoMatch q={q} reset={() => setQ('')}/> :
       view === 'grid' ? (
        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(300px, 1fr))', gap: density === 'compact' ? 12 : 16 }}>
          {filtered.map(e => (
            <EntryCard key={e.id} entry={e}
              selected={selected.includes(e.id)}
              onSelect={(id) => setSelected(arr => arr.includes(id) ? arr.filter(x => x!==id) : [...arr, id])}
              onOpen={openEntry} density={density}/>
          ))}
        </div>
      ) : (
        <div style={{ maxWidth: 820 }}>
          {byDay.map(([day, items]) => (
            <section key={day} style={{ marginBottom: 56 }}>
              <div className="row gap-3" style={{ marginBottom: 16 }}>
                <div className="f-serif" style={{ fontSize: 22, fontStyle:'italic', fontWeight: 450 }}>{dayLabel(day)}</div>
                <div className="hr" style={{ flex: 1 }}/>
                <div className="f-sans" style={{ fontSize: 12, color:'var(--ink-faint)' }}>{new Date(day).toLocaleDateString('en-GB', { day:'numeric', month:'long' })}</div>
              </div>
              <div style={{ display:'grid', gap: 12 }}>
                {items.map(e => (
                  <EntryCard key={e.id} entry={e}
                    selected={selected.includes(e.id)}
                    onSelect={(id) => setSelected(arr => arr.includes(id) ? arr.filter(x => x!==id) : [...arr, id])}
                    onOpen={openEntry} density={density}/>
                ))}
              </div>
            </section>
          ))}
        </div>
      )}

      {/* Loading skeleton (initial) */}
    </div>

    {/* Bulk action bar */}
    {selected.length > 0 && <BulkBar count={selected.length} onClear={() => setSelected([])}/>}
  </div>;
}

function BulkBar({ count, onClear }) {
  return <div className="anim-fade-up" style={{
    position:'absolute', bottom: 24, left:'50%', transform:'translateX(-50%)',
    background:'var(--surface-high)', border:'1px solid var(--line)',
    borderRadius: 999, padding:'8px 10px 8px 20px',
    display:'flex', alignItems:'center', gap: 8,
    boxShadow:'var(--lift-2)',
  }}>
    <span className="f-sans" style={{ fontSize: 13, color:'var(--ink-soft)', marginRight: 8 }}>{count} selected</span>
    <button className="btn-ghost press" style={{ fontSize: 13 }}><I.pin style={{ width: 14, height: 14, marginRight: 6 }}/>Pin</button>
    <button className="btn-ghost press" style={{ fontSize: 13 }}><I.vault style={{ width: 14, height: 14, marginRight: 6 }}/>Vault</button>
    <button className="btn-ghost press" style={{ fontSize: 13, color:'var(--blood)' }}><I.trash style={{ width: 14, height: 14, marginRight: 6 }}/>Delete</button>
    <div className="vr" style={{ height: 18, margin:'0 4px' }}/>
    <button className="btn-ghost press" onClick={onClear} style={{ fontSize: 13 }}><I.x style={{ width: 14, height: 14 }}/></button>
  </div>;
}

function EmptyState() {
  return <div style={{ textAlign:'center', padding:'80px 20px' }}>
    <div style={{
      width: 60, height: 60, borderRadius:'50%', margin:'0 auto 24px',
      background:'var(--ember-wash)', display:'flex', alignItems:'center', justifyContent:'center'
    }}>
      <I.plume style={{ width: 28, height: 28, color:'var(--ember)' }}/>
    </div>
    <h2 className="f-serif" style={{ fontSize: 28, fontWeight: 400, margin: 0, letterSpacing:'-0.01em' }}>
      Nothing yet. That's fine.
    </h2>
    <p className="f-serif" style={{ fontSize: 17, color:'var(--ink-soft)', fontStyle:'italic', marginTop: 10 }}>
      Remember something.
    </p>
  </div>;
}

function NoMatch({ q, reset }) {
  return <div style={{ textAlign:'center', padding:'60px 20px' }}>
    <h3 className="f-serif" style={{ fontSize: 22, fontWeight: 450, margin: 0 }}>
      nothing matches <span style={{ fontStyle:'italic', color:'var(--ink-soft)' }}>"{q}"</span>
    </h3>
    <p className="f-serif" style={{ fontSize: 15, color:'var(--ink-faint)', fontStyle:'italic', marginTop: 8 }}>
      try a looser word. or a feeling.
    </p>
    <button className="btn-secondary press" style={{ marginTop: 20 }} onClick={reset}>Clear search</button>
  </div>;
}

function EntryDetail({ entry, onClose, allEntries }) {
  if (!entry) return null;
  const related = allEntries.filter(e => e.id !== entry.id && e.concepts?.some(c => entry.concepts?.includes(c))).slice(0, 3);
  return <Scrim onClick={onClose}>
    <div onClick={e => e.stopPropagation()} className="anim-scale-in" style={{
      background:'var(--surface-high)', border:'1px solid var(--line-soft)',
      borderRadius: 18, maxWidth: 720, width:'92vw', maxHeight:'88vh',
      display:'flex', flexDirection:'column',
      boxShadow:'var(--lift-3)',
    }}>
      {/* Header */}
      <div className="row" style={{ padding:'18px 24px', borderBottom:'1px solid var(--line-soft)', gap: 12 }}>
        <div className="row gap-2" style={{ color:'var(--ink-faint)' }}>
          <TypeGlyph type={entry.type} size={14}/>
          <span className="f-sans" style={{ fontSize: 12, textTransform:'uppercase', letterSpacing:'0.04em' }}>{entry.type}</span>
        </div>
        <div className="vr" style={{ height: 16 }}/>
        <span className="f-sans" style={{ fontSize: 13, color:'var(--ink-faint)' }}>{relTime(entry.created)}</span>
        {entry.pinned && <span className="row gap-1" style={{ color:'var(--ember)' }}><I.pin style={{ width: 12, height: 12 }}/><span className="f-sans" style={{ fontSize: 12 }}>pinned</span></span>}
        <div style={{ flex: 1 }}/>
        <button className="btn-ghost press" style={{ padding: 8, minHeight: 32 }}><I.pin style={{ width: 16, height: 16 }}/></button>
        <button className="btn-ghost press" style={{ padding: 8, minHeight: 32 }}><I.vault style={{ width: 16, height: 16 }}/></button>
        <button className="btn-ghost press" style={{ padding: 8, minHeight: 32 }}><I.more style={{ width: 16, height: 16 }}/></button>
        <button className="btn-ghost press" style={{ padding: 8, minHeight: 32 }} onClick={onClose}><I.x style={{ width: 16, height: 16 }}/></button>
      </div>
      {/* Body */}
      <div className="scroll" style={{ padding:'32px 40px', flex: 1 }}>
        <h2 className="f-serif" style={{ fontSize: 32, lineHeight: 1.2, fontWeight: 450, margin: 0, letterSpacing:'-0.015em' }}>
          {entry.title}
        </h2>
        <p className="f-serif" style={{ fontSize: 18, lineHeight: 1.65, color:'var(--ink)', margin:'24px 0 32px' }}>
          {entry.body}
        </p>
        <div className="row gap-2" style={{ flexWrap:'wrap', marginBottom: 32 }}>
          {entry.tags.map(t => <span key={t} className="chip">#{t}</span>)}
        </div>

        {/* Concepts */}
        <Micro style={{ marginBottom: 10 }}>Concepts</Micro>
        <div className="row gap-2" style={{ flexWrap:'wrap', marginBottom: 32 }}>
          {entry.concepts?.map(c => <span key={c} className="chip" style={{ background:'var(--ember-wash)', color:'var(--ember)' }}>{c}</span>)}
        </div>

        {/* Related */}
        {related.length > 0 && <>
          <Micro style={{ marginBottom: 14 }}>Also in your memory</Micro>
          <div style={{ display:'grid', gap: 12 }}>
            {related.map(r => (
              <div key={r.id} style={{ borderLeft:'2px solid var(--line-soft)', paddingLeft: 14 }}>
                <div className="f-serif" style={{ fontSize: 16, fontWeight: 450 }}>{r.title}</div>
                <div className="f-serif clip-2" style={{ fontSize: 14, color:'var(--ink-faint)', marginTop: 2 }}>{r.body}</div>
              </div>
            ))}
          </div>
        </>}
      </div>
    </div>
  </Scrim>;
}

Object.assign(window, { MemoryGrid, EntryDetail });
