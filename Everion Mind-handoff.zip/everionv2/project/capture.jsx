/* Capture sheet — HERO MOMENT */

function CaptureSheet({ onClose, onSave, mobile }) {
  const [text, setText] = React.useState('');
  const [type, setType] = React.useState('auto');
  const [vault, setVault] = React.useState(false);
  const [recording, setRecording] = React.useState(false);
  const [showSaved, setShowSaved] = React.useState(false);
  const ref = React.useRef(null);

  React.useEffect(() => {
    setTimeout(() => ref.current?.focus(), 80);
  }, []);

  const inferredType = type !== 'auto' ? type :
    /https?:\/\/|\.com|\.co|aeon|substack/i.test(text) ? 'link' :
    /remind|tomorrow|call|email|text|pick up|don.t forget/i.test(text) ? 'reminder' :
    /idea|what if|maybe|concept|story about/i.test(text) ? 'idea' :
    /\+\d|@\w/.test(text) ? 'contact' : 'note';

  const save = () => {
    if (!text.trim()) return;
    setShowSaved(true);
    setTimeout(() => {
      onSave?.({ text, type: inferredType, vault });
      onClose?.();
    }, 900);
  };

  React.useEffect(() => {
    const h = (e) => {
      if (e.key === 'Escape') onClose?.();
      if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') save();
    };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [text]);

  const types = ['note','link','reminder','idea','contact','file'];
  const canSave = text.trim().length > 0;

  const content = (
    <div onClick={e => e.stopPropagation()} className={mobile ? 'anim-sheet-up' : 'anim-scale-in'} style={{
      background:'var(--surface-high)', border:'1px solid var(--line)',
      borderRadius: mobile ? '28px 28px 0 0' : 28,
      width: mobile ? '100%' : 720, maxWidth:'96vw',
      height: mobile ? '85vh' : 'auto',
      minHeight: mobile ? 'auto' : 300,
      boxShadow:'var(--lift-3)',
      display:'flex', flexDirection:'column',
      position: mobile ? 'absolute' : 'relative',
      bottom: mobile ? 0 : 'auto', left: 0, right: 0,
      paddingBottom: mobile ? 'env(safe-area-inset-bottom, 0px)' : 0,
    }}>
      {mobile && <div style={{ width: 36, height: 4, borderRadius: 2, background:'var(--line)', margin:'12px auto 0' }}/>}

      {/* Textarea front and center. No title. No chrome. */}
      <div style={{ padding: mobile ? '20px 20px 12px' : '28px 28px 16px', flex: 1, display:'flex', flexDirection:'column' }}>
        <textarea ref={ref} value={text} onChange={e => setText(e.target.value)}
          placeholder="remember something…"
          className="f-serif" style={{
            width:'100%', minHeight: 120, flex: 1, resize:'none',
            fontSize: mobile ? 19 : 20, lineHeight: 1.55,
            color:'var(--ink)',
            fontStyle: text ? 'normal' : 'italic'
          }}/>
      </div>

      {/* Type suggestion row — inferred or manual */}
      <div className="row" style={{ padding: mobile ? '0 20px 16px' : '0 28px 20px', gap: 8, flexWrap:'wrap' }}>
        <span className="f-sans" style={{ fontSize: 12, color:'var(--ink-faint)', textTransform:'uppercase', letterSpacing:'0.04em', marginRight: 4 }}>
          {type === 'auto' ? 'inferred' : 'type'}
        </span>
        {types.map(t => {
          const active = inferredType === t;
          const override = type !== 'auto' && type === t;
          return <button key={t} onClick={() => setType(override ? 'auto' : t)}
            className="press f-sans" style={{
              display:'flex', alignItems:'center', gap: 6,
              padding:'4px 10px', minHeight: 24, height: 26, borderRadius: 4,
              background: (active || override) ? 'var(--ember-wash)' : 'transparent',
              color: (active || override) ? 'var(--ember)' : 'var(--ink-faint)',
              border: '1px solid ' + (override ? 'var(--ember)' : 'transparent'),
              fontSize: 12, fontWeight: 500,
            }}>
            <TypeGlyph type={t} size={12}/>{t}
          </button>;
        })}
      </div>

      {/* Bottom bar: actions */}
      <div className="row" style={{
        padding: mobile ? '16px 20px' : '16px 24px',
        borderTop:'1px solid var(--line-soft)',
        justifyContent:'space-between', gap: 12,
        background:'var(--surface)'
      }}>
        <div className="row gap-1">
          <button onClick={() => setRecording(v => !v)} className="btn-ghost press"
            style={{ padding: 10, minHeight: 40, color: recording ? 'var(--ember)' : undefined }}>
            <I.mic style={{ width: 18, height: 18 }}/>
          </button>
          <button className="btn-ghost press" style={{ padding: 10, minHeight: 40 }}><I.attach style={{ width: 18, height: 18 }}/></button>
          <button onClick={() => setVault(v => !v)} className="btn-ghost press"
            style={{ padding: 10, minHeight: 40, color: vault ? 'var(--ember)' : undefined }}>
            <I.vault style={{ width: 18, height: 18 }}/>
          </button>
          {vault && <span className="f-serif" style={{ fontSize: 13, fontStyle:'italic', color:'var(--ember)', marginLeft: 6 }}>vault</span>}
        </div>
        <div className="row gap-3">
          {!mobile && <span className="row gap-1 f-sans" style={{ fontSize: 11, color:'var(--ink-ghost)' }}>
            <Kbd>{window.MOD}</Kbd><Kbd>⏎</Kbd> to save
          </span>}
          <button onClick={save} disabled={!canSave} className="btn-primary press"
            style={{ height: 40, opacity: canSave ? 1 : 0.4, cursor: canSave ? 'pointer' : 'not-allowed' }}>
            <I.send style={{ width: 14, height: 14, marginRight: 8 }}/>
            Remember
          </button>
        </div>
      </div>

      {/* Voice waveform — motes moving horizontally when recording */}
      {recording && <div style={{
        position:'absolute', bottom: 80, left: 28, right: 28,
        height: 40, pointerEvents:'none',
        display:'flex', alignItems:'center', justifyContent:'center', gap: 4,
      }}>
        {Array.from({length: 36}, (_, i) => (
          <span key={i} style={{
            width: 2, height: 4 + Math.random() * 22,
            background:'var(--ember)', opacity: 0.3 + Math.random() * 0.6,
            borderRadius: 2,
            animation: `breathe ${0.6 + Math.random()*1.4}s ease-in-out infinite`,
            animationDelay: -(Math.random() * 2) + 's',
          }}/>
        ))}
      </div>}

      {/* Saved whisper */}
      {showSaved && <div className="anim-fade-in" style={{
        position:'absolute', bottom: 26, left: 28, pointerEvents:'none'
      }}>
        <SerifWhisper>saved.</SerifWhisper>
      </div>}
    </div>
  );

  if (mobile) {
    return <Scrim onClick={onClose} style={{ alignItems:'flex-end' }}>{content}</Scrim>;
  }
  return <Scrim onClick={onClose}>{content}</Scrim>;
}

Object.assign(window, { CaptureSheet });
