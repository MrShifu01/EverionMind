/* Shared UI primitives — buttons, panels, sheets, drifting motes */

function Motes({ count = 28, className = '' }) {
  const motes = React.useMemo(() =>
    Array.from({length: count}, (_, i) => {
      const size = 1 + Math.random() * 3;
      return {
        size,
        top: Math.random() * 100,
        left: Math.random() * 100,
        dx: (Math.random() - 0.5) * 60 + 'px',
        dy: (Math.random() - 0.5) * 80 + 'px',
        dur: 14 + Math.random() * 18,
        delay: Math.random() * -20,
        op: 0.06 + Math.random() * 0.12,
        bHigh: 0.06 + Math.random() * 0.12,
        bLow: 0.02 + Math.random() * 0.05,
      };
    }), [count]);
  return (
    <div className={"motes " + className}>
      {motes.map((m, i) => (
        <div key={i} className="mote" data-ambient style={{
          width: m.size, height: m.size,
          top: m.top + '%', left: m.left + '%',
          opacity: m.op,
          '--dx': m.dx, '--dy': m.dy,
          '--b-high': m.bHigh, '--b-low': m.bLow,
          animation: `drift ${m.dur}s ease-in-out infinite ${m.delay}s, breathe ${8 + Math.random()*6}s ease-in-out infinite`,
        }}/>
      ))}
    </div>
  );
}

function Kbd({ children }) {
  return <span className="f-sans" style={{
    display:'inline-flex', alignItems:'center', justifyContent:'center',
    minWidth: 18, height: 18, padding:'0 5px',
    background:'var(--surface-low)', border:'1px solid var(--line)',
    borderRadius: 4, fontSize: 11, color:'var(--ink-faint)',
    fontWeight: 500,
  }}>{children}</span>;
}

function Dot({ color = 'var(--ink-faint)', size = 6, breathe, style }) {
  return <span style={{
    display:'inline-block', width: size, height: size, borderRadius: '50%',
    background: color, flexShrink: 0,
    animation: breathe ? 'breathe 3.5s ease-in-out infinite' : 'none',
    ...style
  }}/>;
}

function Pill({ children, active, ...rest }) {
  return <button {...rest} className={"chip press " + (active ? 'chip-active' : '')}>{children}</button>;
}

function Scrim({ onClick, children, style }) {
  return <div onClick={onClick} className="anim-fade-in" style={{
    position:'fixed', inset:0, background:'var(--scrim)',
    zIndex: 1000,
    display:'flex', alignItems:'center', justifyContent:'center',
    ...style
  }}>{children}</div>;
}

function Tooltip({ label, children }) {
  const [show, setShow] = React.useState(false);
  return <span style={{ position:'relative', display:'inline-flex' }}
    onMouseEnter={() => setShow(true)} onMouseLeave={() => setShow(false)}>
    {children}
    {show && <span className="f-sans" style={{
      position:'absolute', bottom:'calc(100% + 6px)', left:'50%', transform:'translateX(-50%)',
      background:'var(--surface-high)', border:'1px solid var(--line)',
      padding:'4px 8px', borderRadius: 4, fontSize: 12, color:'var(--ink-soft)',
      whiteSpace:'nowrap', pointerEvents:'none', zIndex: 50,
      boxShadow:'var(--lift-2)'
    }}>{label}</span>}
  </span>;
}

function Toggle({ value, onChange, size = 'md' }) {
  const w = size === 'sm' ? 32 : 40;
  const h = size === 'sm' ? 18 : 22;
  const k = size === 'sm' ? 14 : 18;
  return <button onClick={() => onChange(!value)} role="switch" aria-checked={value}
    className="press" style={{
    width: w, height: h, minHeight: h, borderRadius: 999,
    background: value ? 'var(--ember)' : 'var(--surface-high)',
    border: '1px solid ' + (value ? 'var(--ember)' : 'var(--line)'),
    position:'relative', transition:'background 200ms, border-color 200ms',
    padding: 0,
  }}>
    <span style={{
      position:'absolute', top: 1, left: value ? w - k - 3 : 1,
      width: k, height: k, borderRadius: '50%',
      background: value ? 'oklch(14% 0.03 50)' : 'var(--ink-faint)',
      transition: 'left 200ms cubic-bezier(.16,1,.3,1)',
    }}/>
  </button>;
}

function Segmented({ options, value, onChange }) {
  return <div className="row" style={{
    padding: 3, background:'var(--surface-low)', border:'1px solid var(--line-soft)',
    borderRadius: 8, gap: 2
  }}>
    {options.map(opt => (
      <button key={opt.value} onClick={() => onChange(opt.value)}
        className="f-sans press" style={{
        padding: '6px 12px', minHeight: 28, borderRadius: 6,
        fontSize: 13, fontWeight: 500,
        background: value === opt.value ? 'var(--surface-high)' : 'transparent',
        color: value === opt.value ? 'var(--ink)' : 'var(--ink-faint)',
        border: value === opt.value ? '1px solid var(--line-soft)' : '1px solid transparent',
        transition: 'all 180ms'
      }}>{opt.label}</button>
    ))}
  </div>;
}

// Serif italic feedback text — "saved." style
function SerifWhisper({ children, style }) {
  return <span className="f-serif" style={{
    fontStyle:'italic', fontSize: 15, color:'var(--ink-faint)',
    ...style
  }}>{children}</span>;
}

// Soft section label (micro)
function Micro({ children, style }) {
  return <div className="micro" style={style}>{children}</div>;
}

// Entry type icon
function TypeGlyph({ type, size = 14 }) {
  const Icon = window.TYPE_ICON[type] || window.I.note;
  return <Icon style={{ width: size, height: size }}/>;
}

Object.assign(window, {
  Motes, Kbd, Dot, Pill, Scrim, Tooltip, Toggle, Segmented, SerifWhisper, Micro, TypeGlyph
});
