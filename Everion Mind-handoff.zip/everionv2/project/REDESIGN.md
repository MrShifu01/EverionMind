# Everion — Redesign Spec

**Codename:** Dusk / Vellum *(replacing Neural Obsidian / Neural Alabaster)*
**Status:** v1. Tight enough to ship against. Deviate only with reason.

---

## 1. Philosophy — three commitments

These are the same three commitments as before. The execution is new.

1. **Warmth over sterility.** No flat black, no cool greys, no corporate blue. Every surface carries a hue cast — a warmth that makes the screen feel like a lit room, not a monitor.
2. **Restraint over decoration.** The accent is reserved for *action*. Everything else recedes. One color does one job.
3. **Serif for thought, sans for interface.** A serif carries meaning — titles, entry bodies, transcripts, hero copy, quotes, timestamps on a day page. A sans carries function — nav, labels, metadata, chips, buttons.

### The room, not the tool
Everion is a place a person comes back to. Ambient motion is welcome — motes drifting in a shaft of light, a pulse that matches a resting heartbeat. Nothing asks for attention. Everything waits.

**Target feeling:** The quiet ten minutes between closing your laptop and turning out the light. Alive, but lowered.

---

## 2. Color system — OKLCh

Two themes, `class`-toggled on `<html>`. Dark is default. Light must be just as considered.

### Palette intention
- **Dusk** (dark) — warm charcoal with a sepia undertone. Not black. Not grey. Think: walnut, ash, a banker's lamp.
- **Vellum** (light) — warm paper. Not white. A hand-set page left in afternoon sun.
- **Ember** (accent, reserved) — burnt amber. Calibrated to feel like a single oil-lamp in the room.
- **Moss** (tertiary, rare) — grounded green for "connect / merge / synthesize" actions only.
- **Ink** (error) — deep red-brown, never fire-engine.

### Tokens

```css
/* ── DUSK (dark, default) ── */
--bg:            oklch(14% 0.012 62);     /* page */
--surface:       oklch(17% 0.014 62);     /* card body */
--surface-high:  oklch(21% 0.016 64);     /* raised */
--surface-low:   oklch(11% 0.010 60);     /* recessed / sidebars */
--surface-dim:   oklch(9%  0.008 60);     /* deepest */

--ink:           oklch(94% 0.010 78);     /* primary text */
--ink-soft:      oklch(78% 0.012 72);     /* secondary text */
--ink-faint:     oklch(58% 0.010 68);     /* tertiary / metadata */
--ink-ghost:     oklch(42% 0.008 65);     /* hairlines, placeholders */

--line:          oklch(28% 0.014 64);     /* outline */
--line-soft:     oklch(22% 0.012 62);     /* outline-variant */

--ember:         oklch(72% 0.135 52);     /* accent — action only */
--ember-soft:    oklch(64% 0.120 52);
--ember-wash:    oklch(72% 0.135 52 / 0.14);
--ember-deep:    oklch(30% 0.080 52);     /* backing for ember text */

--moss:          oklch(62% 0.072 152);    /* synthesize / connect */
--moss-wash:     oklch(62% 0.072 152 / 0.12);

--blood:         oklch(58% 0.160 28);     /* error */
--blood-wash:    oklch(58% 0.160 28 / 0.12);

--scrim:         oklch(6% 0.008 60 / 0.72);

/* ── VELLUM (light) ── */
--bg:            oklch(97.5% 0.014 86);
--surface:       oklch(99%   0.008 86);
--surface-high:  oklch(100%  0 0);
--surface-low:   oklch(95.5% 0.016 84);
--surface-dim:   oklch(93%   0.018 82);

--ink:           oklch(22% 0.014 62);
--ink-soft:      oklch(38% 0.014 62);
--ink-faint:     oklch(52% 0.012 62);
--ink-ghost:     oklch(70% 0.010 70);

--line:          oklch(86% 0.012 82);
--line-soft:     oklch(92% 0.010 84);

--ember:         oklch(48% 0.128 48);
--ember-soft:    oklch(54% 0.122 48);
--ember-wash:    oklch(48% 0.128 48 / 0.10);
--ember-deep:    oklch(92% 0.050 50);

--moss:          oklch(42% 0.070 150);
--moss-wash:     oklch(42% 0.070 150 / 0.08);

--blood:         oklch(46% 0.160 28);
--blood-wash:    oklch(46% 0.160 28 / 0.08);

--scrim:         oklch(22% 0.014 62 / 0.42);
```

**Ember discipline.** Ember appears only on:
- Primary buttons (one per view)
- The active nav item (a 2px indicator, not a fill)
- Unsent / draft state dots
- Citation markers in Chat
- Hover on primary actions

Ember does **not** appear on: generic hover states, chips, timestamps, tags, type accents, decorative underlines, icons in nav.

---

## 3. Type

**Content serif:** [Newsreader](https://fonts.google.com/specimen/Newsreader) — variable, optical-size, literary without being precious. Replaces Lora.
**Interface sans:** [Inter Tight](https://fonts.google.com/specimen/Inter+Tight) — quiet, tight metrics, great at small sizes. Replaces DM Sans.
**Mono (rare):** Geist Mono — for keys, codes, timestamps in the graph.

> Never mix serif and sans in the same line of UI copy. If a label and a value are on the same row, they share a family.

### Scale (1rem = 16px)

| Token | Size | Line | Use |
|---|---|---|---|
| `display-xl` | 88 / 1.00 | serif, 400, opsz 72 | Landing hero only |
| `display-lg` | 64 / 1.04 | serif, 400 | Section openers |
| `display` | 48 / 1.08 | serif, 400 | Landing h2 |
| `title-lg` | 32 / 1.15 | serif, 450 | Entry title, page title |
| `title` | 24 / 1.22 | serif, 450 | Card title, modal title |
| `subtitle` | 20 / 1.35 | serif, 420, italic ok | Lede, pull quote |
| `body-lg` | 18 / 1.55 | serif, 400 | Entry body, transcript |
| `body` | 16 / 1.55 | serif, 400 | Long content |
| `ui-lg` | 16 / 1.35 | sans, 500 | Buttons, nav |
| `ui` | 14 / 1.35 | sans, 500 | Chips, labels, row labels |
| `ui-sm` | 13 / 1.3 | sans, 500 | Metadata, timestamps |
| `micro` | 11 / 1.2 | sans, 600, tracking +0.04em, upper | Section labels only |

**Never below 14px on desktop. Never below 16px on mobile inputs** (iOS zoom). Never below 11px on any label.

### Rules
- Entry titles: serif, 450 weight (not bold)
- Entry body: serif, 18/1.55 — this is a reading surface
- Buttons: sans, 500, no uppercase, no letterspacing
- Timestamps: `sans ui-sm` on cards; `serif subtitle` on a day divider in Timeline
- Italic is allowed in Newsreader for quotes and for an in-progress entry title

---

## 4. Space, radii, elevation

### Spacing — 4px grid
`4, 8, 12, 16, 20, 24, 32, 40, 56, 72, 96, 128`

Use 12 as a default interior padding on rows; 20 on cards; 24 inside modals; 32 at page level. Two densities: **Cozy** (default) and **Compact** — Compact scales pad/gap down by one step (16→12, 20→16, etc.).

### Radii
```
--r-xs: 4px    /* chips, keycaps */
--r-sm: 8px    /* inputs, small buttons */
--r-md: 12px   /* cards */
--r-lg: 18px   /* modals, large surfaces */
--r-xl: 28px   /* capture sheet, floating pills */
--r-full: 9999px
```

Everion is *softly* rounded, never pill-happy. Cards: 12. Capture sheet: 28.

### Elevation
Elevation is expressed through **value**, not shadow. A raised surface is lighter than what it sits on (dark) or cleaner than what it sits on (light). Shadows are soft, warm, and only on truly-floating objects (modals, toasts, capture sheet).

```
--lift-1: 0 1px 2px  oklch(6% 0.01 60 / .35);
--lift-2: 0 6px 20px oklch(6% 0.01 60 / .45), 0 2px 6px oklch(6% 0.01 60 / .3);
--lift-3: 0 24px 60px oklch(6% 0.01 60 / .55), 0 8px 16px oklch(6% 0.01 60 / .35);
```

No `box-shadow: 0 0 0 1px` ring hacks. Use `--line` for borders, period.

---

## 5. Motion

**Target:** lower the reader's heart rate. Nothing pulsing for attention.

- **Durations:** 120ms (press), 200ms (local state), 320ms (enter/exit), 600ms (page transition), 6–12s (ambient)
- **Easing:** `cubic-bezier(0.16, 1, 0.3, 1)` for entrances; `cubic-bezier(0.32, 0, 0.67, 0)` for exits; linear for ambient loops
- **Press scale:** `scale(0.97)` on `:active` for all interactive elements
- **Ambient allowed:**
  - Landing hero: slow drifting motes (12s loop, opacity 0.08–0.18)
  - Graph: concept stars breathe ±3% opacity over 8s out of phase
  - Capture sheet open: rise 16px + fade, 320ms
  - Chat streaming: token-level fade-in, 180ms per token cluster
- **Forbidden:**
  - Bouncing (overshoot) easings
  - Spinning loaders except in a last-resort error fallback
  - Shake, flash, wobble
  - Anything that loops faster than 2 Hz

All motion must honor `prefers-reduced-motion: reduce` — reduce to simple opacity transitions at 120ms, kill ambients.

---

## 6. Components — canon

### Buttons
- **Primary** — ember fill, ink-on-ember text. One per view. Height 40 (cozy) / 36 (compact). Radius `sm`. Sans 500.
- **Secondary** — 1px line border, ink text, transparent fill. Hover: fill `surface-high`.
- **Ghost** — no border, ink-soft text, hover fill `surface-high`.
- **Danger** — blood text on transparent; blood-wash fill on hover.
- All buttons: press-scale 0.97, focus-visible ember ring 2px offset 2px.
- Never combine two primaries. Never use shadow on a button.

### Inputs
- 40h (cozy) / 36h (compact). Mobile: 48h.
- Background `surface-low`, 1px `line` border, 16px font-size on mobile.
- Focus: border `ember`, no fill change, no ring.
- Error: border `blood`, helper text blood below.
- Never float labels. Labels sit above, `micro` style.

### Cards (Entry cards)
- Radius `md`. Background `surface`. 1px `line-soft` border.
- Hover: background `surface-high`, border `line`. No lift, no shadow, no translate.
- Pinned: a single 2px ember bar on the left side, `surface-high` background.
- Selected (bulk): ember-wash overlay, ember border.
- Critical reminder: a 5% blood tint under the card background (still warm).

### Chips / tags
- Radius `xs`. Height 22. Sans `ui-sm`.
- Background `surface-high`, text `ink-soft`. No border.
- Active: ember-wash background, ember text.

### Nav — desktop sidebar
- Width 240. Background `surface-low`. 1px right border `line-soft`.
- Items: 36h, sans `ui`, ink-soft. Icon + label, 12 gap.
- Hover: background `surface`, ink.
- Active: a 2px `ember` bar on the left edge, ink text, no fill.

### Nav — mobile bottom
- 5 items. Background `surface-low`. Top border `line-soft`.
- 48h rows min; 68h including safe-area.
- Active: icon ember, label `ui-sm` ember. Inactive: icon `ink-faint`, label `ink-faint`.

### Modals
- Radius `lg`. Background `surface-high`. `--lift-3`.
- Scrim covers with `--scrim`. Click-out to dismiss.
- Enter: fade + rise 8px, 320ms.

### Toasts
- Bottom-center. Radius `full`. Sans `ui`.
- Undo: ink text + "Undo" in ember, 12s auto-dismiss.
- Save-error: blood border, blood text.
- Background task: a thin ember progress line along the bottom edge.
- Never stack more than 2.

### The Capture Bar (hero component)
Radius `xl`. Background `surface-high`. 1px `line`. `--lift-2` only when open.
- **Closed (desktop):** fixed top-centered pill, 640 wide, 48h, "Remember something…" placeholder in `ink-faint` serif italic. `⌘K` or `⌘N` keys on the right.
- **Open:** expands to 720×min-260. Top row: type chips (Note · Link · Idea · Reminder · Contact · File). Middle: textarea, serif `body-lg`. Bottom: voice, paste, attach, vault toggle, send.
- **Mobile:** a floating round 56px ember button bottom-right, 16px above safe-area. Tap opens a bottom sheet at 85vh.

### The Chat window
- Messages as speech, not cards. User: right-aligned, sans `body`. Assistant: left-aligned, serif `body-lg` — the AI speaks in the same voice as your notes. No avatars.
- Tool calls: collapsible pill — `searched 4 entries · ideas, dad` — click to expand.
- Citations: tiny ember superscripts `¹²³` linking to entries in a right-rail panel on desktop, or a sheet on mobile.
- Streaming: token clusters fade in 180ms. A single slowly-breathing dot while waiting, not three bouncing dots.

### The Graph (hero component)
Metaphor: **constellations**. See §8.

### Forbidden patterns
- Glassmorphism / frosted panels
- Drop-shadowed cards on a grey background
- A "trusted by logos" strip on landing
- Gradient backgrounds covering >20% of a view
- Emoji in UI chrome (content can have whatever the user types)
- Skeuomorphic textures, paper dithers, film grain overlays
- Filled icons — line-art icons only, 1.5px stroke, rounded joins, consistent at 16 and 20
- A 3rd accent color. Ever.
- Pulsing attention (anything above 1 Hz that isn't user-triggered)

---

## 7. Hero moments — the three things worth the pixels

### A. The landing hero
A single dark screen. Top-centered: wordmark in serif, `display-xl`, soft ember dot after "Everion" — one lit lamp. Below: one sentence of serif — *"A quiet room for the things you want to remember."* Below that: an actual live capture bar (not a screenshot) — typing in it animates the cursor; it feels like the product has already started.

Behind everything: a field of 40–60 motes, 1–3px, drifting at 4–8px/s, ember at 5–14% opacity. `prefers-reduced-motion` kills them.

No other chrome above the fold. Nav is tucked at the top-right in `ui-sm` ink-faint.

### B. Capture sheet
The entire product succeeds or fails on this moment. Success test: user saves a second thing without prompting. Rules:
- Opens in 180ms. The textarea is focused before the animation finishes.
- No modal chrome before the textarea. No "New entry" title. No form.
- Type chips are suggestions, not requirements — Everion infers type from content.
- Voice is a single orb button; tapping it visualizes the waveform as a slow horizontal line of motes, not a bar-meter.
- Save: ⌘⏎ on desktop, send button on mobile. Save feedback: a single serif italic word bottom-left — *saved.* — that fades out over 900ms.

### C. Chat
Chat is a **room in the house**, not the whole house. The bar to start a chat sits at the bottom of any view; opening Chat slides a right-panel in on desktop (60% width) or full-sheet on mobile.
- Streaming happens at the token-cluster level with a gentle fade, never character-by-character flicker.
- Every synthesized answer has citations (ember superscripts). Clicking one pops a 2-column entry preview in a right-rail — hover on mobile opens a sheet.
- Tool calls are visible by default but collapsed to a single line (`Searched ideas, dad – 4 results`), clickable to expand. Never hide reasoning; never drown in it.
- Empty state: serif italic — *"Ask me anything about what you've written down."* No example chips. The silence is the invitation.

---

## 8. The knowledge graph — the night sky

**Rejected metaphors:** force-directed org chart, skill tree, tag cloud, mindmap.
**Chosen:** constellations. A dark field. Each concept is a star — brightness proportional to frequency of appearance. Edges are faint curved ink lines, drawn only between concepts that co-occur above a threshold, 8–14% opacity.

- Stars breathe ±3% opacity out of phase, 6–10s period.
- Hover a star → it brightens to ember, its edges to 32%. Its name appears serif `subtitle`, italic, 8px below.
- Click → a rail panel opens with the concept's entries, co-concepts, and a pull quote.
- Drag to pan. Scroll to zoom — but zooming past 2× reveals smaller satellite concepts that were invisible before (a reward for looking closer).
- **Never show all labels at once.** Most stars are unlabeled. The eye finds shapes.
- Color: stars are `ink` with varying alpha. No rainbow categorization. The night sky is monochrome, and that's why it's beautiful.

---

## 9. Surfaces & Information architecture

### Nav (both)
- Capture (floating, not a nav item)
- Memory (the grid; also houses Timeline as a toggle — not a separate view)
- Chat
- Graph
- Todos
- Vault
- Settings (gear, bottom)

Removed as distinct nav: Trash (accessible from Settings → Storage, or from the bulk action bar).

### Desktop layout
`[240 sidebar] [flexible content] [optional 380 rail: chat / entry detail / concept preview]`

The rail is context-specific, summonable, and never mandatory.

### Mobile layout
- Top: `48h` header with brain name + search icon + menu icon.
- Bottom: 5-item nav (Memory, Chat, Capture[floating above], Todos, Vault).
- Capture is the center floating button with ember fill.

### Omnisearch (⌘K)
Floating panel, 640 wide, `surface-high`, `--lift-3`. Segments:
- Entries (serif titles)
- Concepts (sans, italic)
- Commands (sans, mono suffix for shortcut)

Arrow keys navigate, ⏎ selects, esc closes.

---

## 10. Offline, sync, vault — honest status

- Header brain name has a **state dot** next to it: ember = unsynced ops pending, moss = fully synced, ink-soft = offline. A click opens a small popover showing: "3 pending, 1 failed. Reconnecting in 4s." Plain language, counts, never a spinner.
- Vault lock state is shown as a serif italic word under the header: *locked* or *unlocked for 9:52* — a countdown, not an icon.

---

## 11. Copy voice

Serif, declarative, lowercase-friendly, never exclamatory.
- Empty Memory: *"Nothing yet. That's fine. Remember something."*
- Empty Chat: *"Ask me anything about what you've written down."*
- Save success: *"saved."*
- Save error: *"not saved yet — we'll keep trying."*
- Offline: *"you're offline. I'm holding everything."*
- 404: *"that page isn't here. try the memory grid."*

Never use: *Awesome!*, *Oops!*, *Gotcha!*, em-dashes-for-drama, exclamation marks, emoji.

---

## 12. Accessibility & device rules

- WCAG AA contrast minimum for all text. `ink-soft` on `surface` = 7.1:1 (dark) / 6.8:1 (light). Verified.
- Focus visible on every interactive element. Ember ring 2px, offset 2px.
- Min 44×44 touch target on mobile. 16px min input font-size.
- Safe-area insets on bottom nav, floating capture, and toasts: `env(safe-area-inset-bottom)`.
- All interactive elements reachable by keyboard; custom controls get `role` + `aria-*`.
- Variable font weights used, never simulated with `font-weight: bold` on a non-variable cut.

---

## 13. Migration — what to change in the repo

(Full patch deferred to when we sit with the code open. This is the token-level handoff.)

### `src/index.css` — replace the `@theme` block with the Dusk/Vellum tokens in §2. Map old → new:

| Old token | New token |
|---|---|
| `--color-background` | `--bg` |
| `--color-surface-container-*` | `--surface-*` |
| `--color-primary` | `--ember` |
| `--color-tertiary` | `--moss` |
| `--color-error` | `--blood` |
| `--color-on-surface` | `--ink` |
| `--color-on-surface-variant` | `--ink-soft` |
| `--color-outline` / `-variant` | `--line` / `--line-soft` |
| `--font-family-headline` | Newsreader |
| `--font-family-body/label` | Inter Tight |

### Keep
- `press-scale` utility (0.97 on :active) — this was right.
- `prefers-reduced-motion` override — this was right.
- The 16px iOS-zoom guard.
- The 44px min-touch rule.
- The `entry-card` CSS-native hover approach.

### Drop
- `tw-animate-css` dependency (we define our own 4 keyframes).
- `glass-panel` / `surface-panel` legacy aliases.
- Any shadow on `surface-*` tokens.
- Lora + DM Sans imports. Replace with Newsreader + Inter Tight.

### Component touches (presentation only, no behavior changes)
- `DesktopSidebar` — replace hover fill with `surface`; remove icon tint; add ember 2px left bar on active.
- `BottomNav` — replace filled active icons with line-art + ember tint on icon and label.
- `CaptureSheet` — swap rounded-3xl for `r-xl` (28px). Remove the top title row. Type chips become suggestion pills below the textarea.
- `EntryList` / card — remove shadows; introduce the pinned ember bar; tighten to 20px pad / 12px gap.
- `ChatView` — assistant messages in serif 18/1.55; tool calls become one-line collapsibles; citation markers render as sup with ember.
- `OmniSearch` — sectioned results (Entries / Concepts / Commands); serif titles in the Entries section.
- `DetailModal` — radius `lg`; remove inner shadows; entry body rendered in serif 18/1.55.
- `VaultView` — remove the "vault" iconography; express state with a serif italic countdown.
- `BottomNav` / FAB — FAB becomes the Capture entrypoint on mobile; center position, ember fill.

---

**End of spec.**
