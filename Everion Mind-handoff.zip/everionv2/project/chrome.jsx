/* Chrome — desktop sidebar, mobile bottom nav, top bar */

function Sidebar({ view, go, unsynced }) {
  const items = [
    { id: 'memory',  label: 'Memory',    icon: I.grid },
    { id: 'chat',    label: 'Chat',      icon: I.chat },
    { id: 'graph',   label: 'Graph',     icon: I.graph },
    { id: 'todos',   label: 'Todos',     icon: I.check },
    { id: 'vault',   label: 'Vault',     icon: I.vault },
  ];
  return <aside style={{
    width: 240, minWidth: 240, height:'100%',
    background:'var(--surface-low)', borderRight:'1px solid var(--line-soft)',
    display:'flex', flexDirection:'column',
  }}>
    <div style={{ padding:'20px 20px 16px' }}>
      <div className="row gap-2 press" style={{ cursor:'pointer' }} onClick={() => go('landing')}>
        <span className="f-serif" style={{ fontSize: 20, fontWeight: 450, letterSpacing:'-0.01em' }}>Everion</span>
        <Dot color="var(--ember)" size={4} breathe/>
      </div>
      <div className="row gap-2" style={{ marginTop: 20, padding:'8px 10px', background:'var(--surface)', border:'1px solid var(--line-soft)', borderRadius: 8 }}>
        <Dot color={unsynced ? 'var(--ember)' : 'var(--moss)'} size={6}/>
        <div className="f-serif" style={{ fontSize: 14, fontStyle:'italic', color:'var(--ink)' }}>{BRAIN_NAME}</div>
      </div>
      {unsynced > 0 && <div className="micro" style={{ marginTop: 8, padding:'0 10px', color:'var(--ember)' }}>{unsynced} pending</div>}
    </div>

    <nav style={{ padding:'8px 10px', flex: 1 }}>
      {items.map(it => {
        const active = view === it.id;
        return <button key={it.id} onClick={() => go(it.id)} className="press f-sans"
          style={{
            display:'flex', alignItems:'center', gap: 12,
            width:'100%', padding:'0 14px', minHeight: 40, height: 40,
            borderRadius: 6, fontSize: 14, fontWeight: 500,
            color: active ? 'var(--ink)' : 'var(--ink-soft)',
            background: active ? 'var(--surface)' : 'transparent',
            position:'relative', transition:'background 180ms, color 180ms',
          }}>
          {active && <span style={{ position:'absolute', left: -10, top: 8, bottom: 8, width: 2, background:'var(--ember)', borderRadius: 2 }}/>}
          <it.icon style={{ width: 18, height: 18, color: active ? 'var(--ink)' : 'var(--ink-faint)' }}/>
          {it.label}
        </button>;
      })}
    </nav>

    <div style={{ padding:'12px 10px', borderTop:'1px solid var(--line-soft)' }}>
      <button onClick={() => go('settings')} className="press f-sans" style={{
        display:'flex', alignItems:'center', gap: 12, width:'100%',
        padding:'0 14px', minHeight: 40, borderRadius: 6, fontSize: 14, fontWeight: 500,
        color: view === 'settings' ? 'var(--ink)' : 'var(--ink-soft)',
      }}>
        <I.gear style={{ width: 18, height: 18, color:'var(--ink-faint)' }}/>
        Settings
      </button>
      <button onClick={() => go('trash')} className="press f-sans" style={{
        display:'flex', alignItems:'center', gap: 12, width:'100%',
        padding:'0 14px', minHeight: 40, borderRadius: 6, fontSize: 14, fontWeight: 500,
        color: view === 'trash' ? 'var(--ink)' : 'var(--ink-soft)',
      }}>
        <I.trash style={{ width: 18, height: 18, color:'var(--ink-faint)' }}/>
        Trash
      </button>
    </div>
  </aside>;
}

function TopBar({ title, subtitle, right, onSearch, vaultUnlocked }) {
  return <header style={{
    display:'flex', alignItems:'center', justifyContent:'space-between',
    padding:'18px 32px', borderBottom:'1px solid var(--line-soft)',
    minHeight: 68, background:'var(--bg)', gap: 20
  }}>
    <div style={{ minWidth: 0 }}>
      <h1 className="f-serif nowrap" style={{ fontSize: 22, fontWeight: 450, margin: 0, letterSpacing:'-0.01em' }}>{title}</h1>
      {subtitle && <div className="f-serif" style={{ fontSize: 13, color:'var(--ink-faint)', fontStyle:'italic', marginTop: 2 }}>{subtitle}</div>}
    </div>
    <div className="row gap-2">
      <button className="press f-sans" onClick={onSearch} style={{
        display:'flex', alignItems:'center', gap: 10,
        padding:'0 12px 0 14px', height: 36, minHeight: 36,
        border:'1px solid var(--line-soft)', borderRadius: 8,
        background:'var(--surface)', color:'var(--ink-faint)',
        fontSize: 13, width: 260, justifyContent:'space-between',
        transition:'border-color 180ms'
      }}>
        <span className="row gap-2"><I.search style={{ width: 14, height: 14 }}/>Search everything</span>
        <span className="row gap-1"><Kbd>{window.MOD}</Kbd><Kbd>K</Kbd></span>
      </button>
      {right}
    </div>
  </header>;
}

function BottomNav({ view, go }) {
  const items = [
    { id: 'memory', label: 'Memory', icon: I.grid },
    { id: 'chat',   label: 'Chat',   icon: I.chat },
    { id: 'capture', center: true },
    { id: 'todos',  label: 'Todos',  icon: I.check },
    { id: 'graph',  label: 'Graph',  icon: I.graph },
  ];
  return <nav style={{
    position:'fixed', bottom: 0, left: 0, right: 0,
    display:'flex', alignItems:'center', justifyContent:'space-around',
    background:'var(--surface-low)', borderTop:'1px solid var(--line-soft)',
    paddingBottom:'env(safe-area-inset-bottom, 0px)', height: 68,
    zIndex: 10,
  }}>
    {items.map(it => it.center ? (
      <button key={it.id} onClick={() => go('capture-mobile')} className="press"
        style={{
          width: 56, height: 56, minHeight: 56, borderRadius:'50%',
          background:'var(--ember)', color:'oklch(14% 0.03 50)',
          display:'flex', alignItems:'center', justifyContent:'center',
          boxShadow:'var(--lift-2)', marginTop: -28, flexShrink: 0,
        }} aria-label="Capture">
        <I.plus style={{ width: 22, height: 22 }}/>
      </button>
    ) : (
      <button key={it.id} onClick={() => go(it.id)} className="press" style={{
        display:'flex', flexDirection:'column', alignItems:'center', gap: 4,
        padding: '8px 12px', minHeight: 56, flex: 1,
        color: view === it.id ? 'var(--ember)' : 'var(--ink-faint)',
      }}>
        <it.icon style={{ width: 20, height: 20 }}/>
        <span className="f-sans" style={{ fontSize: 11, fontWeight: 500 }}>{it.label}</span>
      </button>
    ))}
  </nav>;
}

function MobileHeader({ title, onSearch, onMenu }) {
  return <header style={{
    position:'sticky', top: 0, zIndex: 10,
    padding:'14px 16px', display:'flex', alignItems:'center', justifyContent:'space-between',
    background:'var(--bg)', borderBottom:'1px solid var(--line-soft)',
  }}>
    <button className="btn-ghost press" onClick={onMenu} style={{ padding: 8, minHeight: 36 }}>
      <I.menu style={{ width: 20, height: 20 }}/>
    </button>
    <div className="f-serif" style={{ fontSize: 17, fontWeight: 450 }}>{title}</div>
    <button className="btn-ghost press" onClick={onSearch} style={{ padding: 8, minHeight: 36 }}>
      <I.search style={{ width: 18, height: 18 }}/>
    </button>
  </header>;
}

function FloatingCapture({ onClick }) {
  return <button onClick={onClick} className="press f-sans"
    aria-label="Remember something"
    style={{
      position:'fixed', bottom: 28, right: 28,
      zIndex: 30,
      display:'flex', alignItems:'center', gap: 10,
      background:'var(--surface-high)', border:'1px solid var(--line)', borderRadius: 28,
      minHeight: 44, height: 44, padding:'0 8px 0 18px',
      color:'var(--ink-soft)', fontSize: 14,
      boxShadow:'var(--lift-2)',
      transition:'box-shadow 240ms, border-color 240ms, transform 140ms',
    }}>
    <I.plume style={{ width: 16, height: 16, color:'var(--ember)' }}/>
    <span className="f-serif" style={{ fontStyle:'italic', fontSize: 14 }}>remember…</span>
    <span className="row gap-1" style={{ padding:'4px 6px' }}><Kbd>{window.MOD}</Kbd><Kbd>N</Kbd></span>
  </button>;
}

Object.assign(window, { Sidebar, TopBar, BottomNav, MobileHeader, FloatingCapture });
