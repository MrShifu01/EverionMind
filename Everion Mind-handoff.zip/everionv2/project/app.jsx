/* App shell — routing, tweaks, overlays. Shared by all three variants. */

const { useState, useEffect, useRef, useCallback } = React;

function useTweaks() {
  const [t, setT] = useState(() => {
    try { return { ...TWEAK_DEFAULTS, ...JSON.parse(localStorage.getItem('everion:tweaks:' + window.VARIANT) || '{}') }; }
    catch { return TWEAK_DEFAULTS; }
  });
  useEffect(() => {
    localStorage.setItem('everion:tweaks:' + window.VARIANT, JSON.stringify(t));
    const html = document.documentElement;
    html.classList.remove('theme-dark','theme-light'); html.classList.add('theme-' + t.theme);
    html.classList.remove('density-cozy','density-compact'); html.classList.add('density-' + t.density);
    html.classList.remove('motion-ambient','motion-minimal','motion-off'); html.classList.add('motion-' + t.motion);
    html.classList.remove('accent-ember','accent-iris','accent-moss'); if (t.accent !== 'ember') html.classList.add('accent-' + t.accent);
  }, [t]);
  return [t, (k, v) => setT(s => {
    const next = { ...s, [k]: v };
    window.parent.postMessage({ type:'__edit_mode_set_keys', edits:{ [k]: v } }, '*');
    return next;
  })];
}

function useRoute() {
  const [route, setRoute] = useState(() => localStorage.getItem('everion:route:' + window.VARIANT) || 'landing');
  const go = useCallback((r) => {
    setRoute(r);
    localStorage.setItem('everion:route:' + window.VARIANT, r);
  }, []);
  return [route, go];
}

function TweaksPanel({ tweaks, set, onClose }) {
  return (
    <div className="tweaks-panel">
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom: 8 }}>
        <h4 style={{ margin: 0 }}>Tweaks — {window.VARIANT}</h4>
        <button onClick={onClose} style={{ color:'var(--ink-faint)', padding: 4, minHeight: 20 }}>
          <I.x style={{ width: 14, height: 14 }}/>
        </button>
      </div>

      <div className="tweaks-row">
        <label>Theme</label>
        <div className="tweaks-seg">
          {['dark','light'].map(v => (
            <button key={v} className={tweaks.theme === v ? 'on' : ''} onClick={() => set('theme', v)}>{v}</button>
          ))}
        </div>
      </div>

      <div className="tweaks-row">
        <label>Accent</label>
        <div className="tweaks-seg">
          {['ember','iris','moss'].map(v => (
            <button key={v} className={tweaks.accent === v ? 'on' : ''} onClick={() => set('accent', v)}>{v}</button>
          ))}
        </div>
      </div>

      <div className="tweaks-row">
        <label>Motion</label>
        <div className="tweaks-seg">
          {['ambient','minimal','off'].map(v => (
            <button key={v} className={tweaks.motion === v ? 'on' : ''} onClick={() => set('motion', v)}>{v}</button>
          ))}
        </div>
      </div>

      <div className="tweaks-row">
        <label>Density</label>
        <div className="tweaks-seg">
          {['cozy','compact'].map(v => (
            <button key={v} className={tweaks.density === v ? 'on' : ''} onClick={() => set('density', v)}>{v}</button>
          ))}
        </div>
      </div>

      <div className="tweaks-row">
        <label>Content</label>
        <div className="tweaks-seg">
          <button className={tweaks.populated ? 'on' : ''} onClick={() => set('populated', true)}>populated</button>
          <button className={!tweaks.populated ? 'on' : ''} onClick={() => set('populated', false)}>empty</button>
        </div>
      </div>

      <div style={{ marginTop: 14, paddingTop: 12, borderTop: '1px solid var(--line-soft)', fontFamily: 'var(--f-serif)', fontStyle: 'italic', fontSize: 12, color: 'var(--ink-faint)', lineHeight: 1.5 }}>
        <a href="Everion.html" style={{ color: 'var(--ember)' }}>← switch direction</a>
      </div>
    </div>
  );
}

function App() {
  const [tweaks, setTweak] = useTweaks();
  const [route, go] = useRoute();
  const [openEntryId, setOpenEntryId] = useState(null);
  const [captureOpen, setCaptureOpen] = useState(false);
  const [omniOpen, setOmniOpen] = useState(false);
  const [unsynced, setUnsynced] = useState(2);
  const [showEarlyAccess, setShowEarlyAccess] = useState(true);
  const [showConsent, setShowConsent] = useState(true);
  const [toast, setToast] = useState(null);
  const [tweaksOpen, setTweaksOpen] = useState(false);

  const openEntry = useCallback((e) => setOpenEntryId(e?.id || null), []);
  const entry = openEntryId ? ENTRIES.find(e => e.id === openEntryId) : null;

  useEffect(() => {
    const handler = (e) => {
      if (e.data?.type === '__activate_edit_mode') setTweaksOpen(true);
      if (e.data?.type === '__deactivate_edit_mode') setTweaksOpen(false);
    };
    window.addEventListener('message', handler);
    window.parent.postMessage({ type:'__edit_mode_available' }, '*');
    return () => window.removeEventListener('message', handler);
  }, []);

  useEffect(() => {
    const h = (e) => {
      const mod = e.metaKey || e.ctrlKey;
      if (mod && e.key === 'k') { e.preventDefault(); setOmniOpen(v => !v); }
      if (mod && e.key === 'n') { e.preventDefault(); setCaptureOpen(true); }
      if (e.key === 'Escape') { setOmniOpen(false); setCaptureOpen(false); setOpenEntryId(null); }
    };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, []);

  const fullscreenRoutes = ['landing','login','signup','onboarding','privacy','terms','404'];
  const isFull = fullscreenRoutes.includes(route);

  const saveCapture = () => {
    setCaptureOpen(false);
    setToast({ kind:'undo', text:'saved to memory', key: Date.now() });
    setUnsynced(u => u + 1);
    setTimeout(() => setToast(t => (t && t.kind === 'undo' ? null : t)), 3600);
  };

  const routeTitle = (r) => ({ memory:'Memory', chat:'Chat', graph:'Graph', todos:'Todos', vault:'Vault', trash:'Trash', settings:'Settings' }[r] || 'Everion');
  const variantLabel = { dusk: 'Dusk / Vellum', paper: 'Paper / Ink', bronze: 'Bronze / Slate' }[window.VARIANT];

  return (
    <>
      {isFull ? (
        route === 'landing'  ? <Landing go={go} tweaks={tweaks}/> :
        route === 'login'    ? <LoginScreen go={go} mode="login"/> :
        route === 'signup'   ? <LoginScreen go={go} mode="signup"/> :
        route === 'onboarding' ? <Onboarding go={go}/> :
        route === 'privacy'  ? <LegalPage go={go} page="privacy"/> :
        route === 'terms'    ? <LegalPage go={go} page="terms"/> :
        <NotFound go={go}/>
      ) : (
        <div className="app-shell">
          <div className="desktop-only" style={{ display:'flex' }}>
            <Sidebar view={route} go={go} unsynced={unsynced}/>
          </div>

          <div className="main-col">
            {showEarlyAccess && <EarlyAccessBanner onClose={() => setShowEarlyAccess(false)}/>}

            <div className="mobile-only" style={{ flexShrink: 0 }}>
              <MobileHeader onSearch={() => setOmniOpen(true)} title={routeTitle(route)}/>
            </div>

            <main style={{ flex: 1, overflow:'hidden', position:'relative' }}>
              {route === 'memory'   && <MemoryGrid go={go} openEntry={openEntry} density={tweaks.density} populated={tweaks.populated} onOmni={() => setOmniOpen(true)}/>}
              {route === 'chat'     && <ChatView populated={tweaks.populated} openEntry={openEntry}/>}
              {route === 'graph'    && <GraphView motion={tweaks.motion} openEntry={openEntry}/>}
              {route === 'todos'    && <TodosView openEntry={openEntry}/>}
              {route === 'vault'    && <VaultView openEntry={openEntry}/>}
              {route === 'trash'    && <TrashView openEntry={openEntry}/>}
              {route === 'settings' && <SettingsView/>}
            </main>

            <div className="mobile-only" style={{ flexShrink: 0 }}>
              <BottomNav view={route} go={go} onCapture={() => setCaptureOpen(true)}/>
            </div>

            <div className="desktop-only">
              <FloatingCapture onClick={() => setCaptureOpen(true)}/>
            </div>
          </div>
        </div>
      )}

      <div className="variant-badge">{variantLabel}</div>

      {entry && <EntryDetail entry={entry} onClose={() => setOpenEntryId(null)} allEntries={ENTRIES}/>}
      {captureOpen && <CaptureSheet onClose={() => setCaptureOpen(false)} onSave={saveCapture}/>}
      {omniOpen && <OmniSearch onClose={() => setOmniOpen(false)} go={go} openEntry={openEntry}/>}

      {showConsent && route === 'landing' && <ConsentBanner onAccept={() => setShowConsent(false)}/>}
      {toast?.kind === 'undo' && <UndoToast key={toast.key} text={toast.text} onUndo={() => setToast(null)} onDismiss={() => setToast(null)}/>}

      {tweaksOpen && <TweaksPanel tweaks={tweaks} set={setTweak} onClose={() => setTweaksOpen(false)}/>}
    </>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
