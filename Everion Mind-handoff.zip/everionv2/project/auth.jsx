/* Auth + Onboarding + Privacy + Terms + 404 */

function LoginScreen({ go, mode = 'login' }) {
  const [email, setEmail] = React.useState('');
  const [sent, setSent] = React.useState(false);
  const [inviteMode, setInviteMode] = React.useState(false);
  return <div style={{ height:'100%', display:'flex', background:'var(--bg)', position:'relative', overflow:'hidden' }}>
    <Motes count={22}/>
    {/* Left — canvas */}
    <div style={{ flex: 1, display:'flex', alignItems:'center', justifyContent:'center', padding: 48, position:'relative' }}>
      <div style={{
        position:'absolute', top:'40%', left:'50%', transform:'translate(-50%, -50%)',
        width: 600, height: 600, borderRadius:'50%',
        background:'radial-gradient(circle, var(--ember-wash) 0%, transparent 65%)',
        pointerEvents:'none'
      }}/>
      <div style={{ position:'relative', maxWidth: 420, width:'100%' }}>
        <div className="row gap-2" style={{ marginBottom: 56, cursor:'pointer' }} onClick={() => go('landing')}>
          <span className="f-serif" style={{ fontSize: 22, fontWeight: 450 }}>Everion</span>
          <Dot color="var(--ember)" size={5} breathe/>
        </div>
        <h1 className="f-serif" style={{ fontSize: 44, lineHeight: 1.05, fontWeight: 400, margin: 0, letterSpacing:'-0.02em' }}>
          {sent ? <>check your mail.</>
            : mode === 'signup' ? <>welcome in.<br/><span style={{ fontStyle:'italic', color:'var(--ink-soft)' }}>let's get you a room.</span></>
            : <>welcome back.</>}
        </h1>
        <p className="f-serif" style={{ fontSize: 17, lineHeight: 1.55, color:'var(--ink-soft)', margin: '20px 0 36px' }}>
          {sent ? 'we sent a magic link to ' + email + '. it expires in ten minutes.'
            : 'no passwords here. type your email and we\'ll send a link.'}
        </p>

        {!sent && <>
          <Micro style={{ marginBottom: 8 }}>email</Micro>
          <input className="input f-sans" type="email" value={email} onChange={e => setEmail(e.target.value)}
            placeholder="you@yourdomain.com" style={{ height: 48, fontSize: 16 }}/>

          {inviteMode && <>
            <Micro style={{ marginBottom: 8, marginTop: 20 }}>invite token</Micro>
            <input className="input f-sans" style={{ height: 48, fontSize: 16 }} placeholder="paste your invite token"/>
          </>}

          <button className="btn-primary press" style={{ width:'100%', height: 48, marginTop: 24, fontSize: 15 }}
            onClick={() => email.includes('@') && setSent(true)}>
            {mode === 'signup' ? 'Send sign-up link' : 'Send sign-in link'}
          </button>

          <div className="row" style={{ marginTop: 24, justifyContent:'space-between', fontSize: 13 }}>
            <button className="press f-sans" style={{ color:'var(--ink-faint)', minHeight: 20 }}
              onClick={() => setInviteMode(v => !v)}>
              {inviteMode ? 'no invite?' : 'have an invite token?'}
            </button>
            <button className="press f-sans" style={{ color:'var(--ink-faint)', minHeight: 20 }}
              onClick={() => go(mode === 'login' ? 'signup' : 'login')}>
              {mode === 'login' ? 'new here?' : 'already have an account?'}
            </button>
          </div>
        </>}

        {sent && <button className="btn-secondary press" style={{ marginTop: 12 }} onClick={() => go(mode === 'signup' ? 'onboarding' : 'memory')}>
          continue (demo) →
        </button>}
      </div>
    </div>
    {/* Right — quote panel */}
    <div style={{ width: 420, background:'var(--surface-low)', borderLeft:'1px solid var(--line-soft)', padding: 56, display:'flex', flexDirection:'column', justifyContent:'space-between' }}>
      <Micro>from someone who lives here</Micro>
      <div>
        <p className="f-serif" style={{ fontSize: 24, lineHeight: 1.35, fontWeight: 400, letterSpacing:'-0.005em', fontStyle:'italic', color:'var(--ink)' }}>
          "It's the only app I keep open all day. The ritual of putting a thing down and knowing where it went — I didn't know I needed that."
        </p>
        <div className="f-sans" style={{ marginTop: 20, fontSize: 13, color:'var(--ink-faint)' }}>— M., writer, lives in her Everion since last summer</div>
      </div>
      <div className="f-serif" style={{ fontSize: 14, fontStyle:'italic', color:'var(--ink-ghost)' }}>private · offline-first · end-to-end encrypted vault</div>
    </div>
  </div>;
}

function Onboarding({ go }) {
  const [step, setStep] = React.useState(0);
  const [firstEntry, setFirstEntry] = React.useState('');
  const [name, setName] = React.useState('');
  const [themes, setThemes] = React.useState([]);

  const toggleTheme = (t) => setThemes(arr => arr.includes(t) ? arr.filter(x => x !== t) : [...arr, t]);

  const steps = [
    {
      q: "first, what should we call you?",
      sub: "just a first name is fine. this is private.",
      body: <input className="input f-serif" autoFocus placeholder="your name"
        value={name} onChange={e => setName(e.target.value)}
        style={{ height: 56, fontSize: 24, border:'0', borderBottom:'1px solid var(--line)', borderRadius: 0, padding: '0 0 10px 0' }}/>,
      canNext: name.length > 0,
    },
    {
      q: "what's one thing you want to not forget?",
      sub: "anything. this will be your first entry. no pressure — you can delete it in a second.",
      body: <textarea className="f-serif" autoFocus placeholder={`${name ? name + ', t' : 't'}ype anything here…`}
        value={firstEntry} onChange={e => setFirstEntry(e.target.value)}
        style={{
          width:'100%', minHeight: 160, resize:'none',
          fontSize: 22, lineHeight: 1.5,
          padding: 0, background:'transparent',
          borderBottom:'1px solid var(--line)', borderRadius: 0,
        }}/>,
      canNext: firstEntry.length > 2,
    },
    {
      q: "what kinds of things will end up here?",
      sub: "pick what resonates — we use this to stay out of your way.",
      body: <div className="row gap-2" style={{ flexWrap:'wrap' }}>
        {["family & friends","reading","work","ideas & writing","home","health","travel","dreams & feelings","admin"].map(t => (
          <button key={t} onClick={() => toggleTheme(t)} className="press f-serif"
            style={{
              padding:'10px 18px', minHeight: 40, borderRadius: 999,
              background: themes.includes(t) ? 'var(--ember-wash)' : 'var(--surface)',
              color: themes.includes(t) ? 'var(--ember)' : 'var(--ink-soft)',
              border: '1px solid ' + (themes.includes(t) ? 'var(--ember)' : 'var(--line)'),
              fontSize: 16, transition:'all 180ms'
            }}>{t}</button>
        ))}
      </div>,
      canNext: true,
    },
    {
      q: "and that's it.",
      sub: `${name ? name + ', y' : 'y'}our room is ready. remember one more thing before you come in.`,
      body: <div style={{
        background:'var(--surface)', border:'1px solid var(--line-soft)', borderRadius: 12, padding: 20
      }}>
        <div className="f-serif" style={{ fontSize: 16, lineHeight: 1.5 }}>{firstEntry || 'your first entry lives here.'}</div>
        <div className="row gap-2" style={{ marginTop: 14, flexWrap:'wrap' }}>
          <span className="chip"><TypeGlyph type="note"/> note</span>
          {themes.slice(0,3).map(t => <span key={t} className="chip">{t.split(' ')[0]}</span>)}
        </div>
      </div>,
      canNext: true,
    },
  ];

  const cur = steps[step];

  return <div style={{ height:'100%', display:'flex', flexDirection:'column', background:'var(--bg)', position:'relative', overflow:'hidden' }}>
    <Motes count={18}/>
    <div className="row" style={{ padding: 24, justifyContent:'space-between' }}>
      <div className="row gap-2">
        <span className="f-serif" style={{ fontSize: 18, fontWeight: 450 }}>Everion</span>
        <Dot color="var(--ember)" size={4}/>
      </div>
      <div className="row gap-2">
        {steps.map((_, i) => (
          <span key={i} style={{
            width: 24, height: 2, borderRadius: 2,
            background: i <= step ? 'var(--ember)' : 'var(--line)',
            transition:'background 300ms'
          }}/>
        ))}
      </div>
    </div>

    <div style={{ flex: 1, display:'flex', alignItems:'center', justifyContent:'center', padding: 40, position:'relative' }}>
      <div key={step} className="anim-fade-up" style={{ maxWidth: 620, width:'100%' }}>
        <Micro style={{ marginBottom: 20 }}>step {step+1} of {steps.length}</Micro>
        <h2 className="f-serif" style={{ fontSize: 44, lineHeight: 1.1, fontWeight: 400, margin: 0, letterSpacing:'-0.02em' }}>
          {cur.q}
        </h2>
        <p className="f-serif" style={{ fontSize: 17, lineHeight: 1.55, color:'var(--ink-soft)', margin:'12px 0 40px', fontStyle:'italic' }}>
          {cur.sub}
        </p>
        {cur.body}
        <div className="row" style={{ marginTop: 36, justifyContent:'space-between' }}>
          <button className="btn-ghost press" onClick={() => step === 0 ? go('landing') : setStep(s => s-1)}>
            {step === 0 ? 'cancel' : 'back'}
          </button>
          <button className="btn-primary press" disabled={!cur.canNext}
            style={{ opacity: cur.canNext ? 1 : 0.5 }}
            onClick={() => step === steps.length - 1 ? go('memory') : setStep(s => s+1)}>
            {step === steps.length - 1 ? 'open your memory' : 'next'}
          </button>
        </div>
      </div>
    </div>
  </div>;
}

function LegalPage({ go, page }) {
  const content = page === 'privacy' ? {
    title: 'Privacy',
    sub: 'Everion is as private as a notebook in your drawer. Here\'s what that means, exactly.',
    sections: [
      ['What we store', 'Your entries, your concepts, your sync metadata. That\'s it. We do not store your device ID, your IP beyond 24 hours, or any analytics about what you wrote.'],
      ['End-to-end encryption', 'Vault entries are encrypted on your device with a key derived from your passphrase. We never see the key. If you forget it, we can\'t help you recover the vault — that\'s the point.'],
      ['AI processing', 'When you chat with your memory, the entries relevant to your question are sent to the AI provider of your choice (Anthropic by default; bring your own key to route anywhere else). We don\'t train on your data. Providers don\'t either, under our agreements.'],
      ['Offline-first', 'The app works without us. You can export everything, any time, in one click. We designed for the day we disappear.'],
      ['Third parties', 'Only Supabase (database + auth) and your chosen AI provider. No analytics services. No ad networks. No session replay.'],
      ['Your rights', 'Export, delete, transfer. All self-service, no email required. A full account delete scrubs every row we have of you within 48 hours.'],
    ],
  } : {
    title: 'Terms',
    sub: 'Plain English. If any of this needs a lawyer to explain, write to us and we\'ll fix it.',
    sections: [
      ['The deal', 'We give you a room. You put things in it. You own those things. We help you find them.'],
      ['Your account', 'One person per account. You\'re responsible for keeping your email secure. Magic links are disposable — we\'ll email one every time.'],
      ['What you can\'t do', 'Nothing illegal. Nothing that tries to break our service for others. Nothing that\'s someone else\'s copyrighted material they haven\'t let you store. Anything that would make us a courier for malware.'],
      ['What we can\'t do', 'Read your vault. Sell your data. Train on your writing. Keep your data if you ask us not to.'],
      ['Payments', 'Pro is month-to-month. Cancel any time. We refund partial months if you ask politely.'],
      ['If we change these terms', 'We\'ll email you 30 days before anything material changes. Using Everion after that counts as acceptance. If you disagree, export and leave — we won\'t be offended.'],
    ],
  };

  return <div className="scroll" style={{ height:'100%', overflowY:'auto', padding: 0, background:'var(--bg)' }}>
    <header className="row" style={{ padding:'18px 40px', justifyContent:'space-between', borderBottom:'1px solid var(--line-soft)' }}>
      <div className="row gap-2 press" onClick={() => go('landing')} style={{ cursor:'pointer' }}>
        <span className="f-serif" style={{ fontSize: 20, fontWeight: 450 }}>Everion</span>
        <Dot color="var(--ember)" size={4}/>
      </div>
      <button className="btn-ghost press f-sans" style={{ fontSize: 13 }} onClick={() => go('landing')}>← back to home</button>
    </header>
    <div style={{ maxWidth: 720, margin:'0 auto', padding:'80px 40px 120px' }}>
      <Micro style={{ marginBottom: 24 }}>{content.title}</Micro>
      <h1 className="f-serif" style={{ fontSize: 56, lineHeight: 1.05, fontWeight: 400, margin: 0, letterSpacing:'-0.02em' }}>
        {content.title}.
      </h1>
      <p className="f-serif" style={{ fontSize: 20, lineHeight: 1.5, color:'var(--ink-soft)', margin:'24px 0 56px', fontStyle:'italic' }}>
        {content.sub}
      </p>
      {content.sections.map(([h, p]) => (
        <section key={h} style={{ marginBottom: 40 }}>
          <h2 className="f-serif" style={{ fontSize: 24, lineHeight: 1.2, fontWeight: 450, letterSpacing:'-0.01em', margin: 0 }}>{h}</h2>
          <p className="f-serif" style={{ fontSize: 17, lineHeight: 1.65, color:'var(--ink-soft)', marginTop: 12 }}>{p}</p>
        </section>
      ))}
      <div className="hr" style={{ margin:'48px 0 20px' }}/>
      <div className="f-serif" style={{ fontSize: 14, fontStyle:'italic', color:'var(--ink-faint)' }}>
        last touched 21 April 2026. write to hello@everion.app if anything here isn't clear.
      </div>
    </div>
  </div>;
}

function NotFound({ go }) {
  return <div style={{ height:'100%', display:'flex', flexDirection:'column', justifyContent:'center', alignItems:'center', background:'var(--bg)', position:'relative', overflow:'hidden', padding: 40 }}>
    <Motes count={16}/>
    <div style={{ position:'relative', textAlign:'center', maxWidth: 520 }}>
      <div className="f-serif" style={{ fontSize: 140, lineHeight: 1, fontWeight: 400, color:'var(--ink-ghost)', letterSpacing:'-0.04em', fontStyle:'italic' }}>404</div>
      <h1 className="f-serif" style={{ fontSize: 32, lineHeight: 1.2, fontWeight: 400, margin:'16px 0 12px', letterSpacing:'-0.01em' }}>
        that page isn't here.
      </h1>
      <p className="f-serif" style={{ fontSize: 17, color:'var(--ink-soft)', lineHeight: 1.55, fontStyle:'italic' }}>
        try the memory grid — most things live there.
      </p>
      <div className="row gap-3 center" style={{ marginTop: 32 }}>
        <button className="btn-primary press" onClick={() => go('memory')}>open memory</button>
        <button className="btn-secondary press" onClick={() => go('landing')}>back home</button>
      </div>
    </div>
  </div>;
}

Object.assign(window, { LoginScreen, Onboarding, LegalPage, NotFound });
