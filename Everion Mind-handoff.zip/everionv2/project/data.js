/* Shared data — realistic memory content for a thoughtful 30-something */

const BRAIN_NAME = "Hanno's brain";

const ENTRIES = [
  {
    id: "e1",
    type: "note",
    title: "What dad said on Sunday",
    body: "He told me, for the first time that I can remember, that he was proud of me. We were making coffee. I didn't know what to say so I asked if he wanted milk. I think he noticed. I want to remember this.",
    tags: ["family", "dad"],
    concepts: ["father", "memory"],
    created: "2026-04-19T17:04:00",
    pinned: true,
    vault: false,
  },
  {
    id: "e2",
    type: "link",
    title: "The tyranny of the ideal image — Aeon",
    body: "aeon.co/essays/the-tyranny — half-read. The part about 'the idealized self as a form of grief' is the part I want to come back to.",
    tags: ["reading", "psychology"],
    concepts: ["self", "grief"],
    created: "2026-04-18T22:11:00",
    pinned: false,
    vault: false,
  },
  {
    id: "e3",
    type: "reminder",
    title: "Call the dentist — reschedule",
    body: "The one on Bree St. They've left two voicemails. Tuesday morning ideally.",
    tags: ["admin"],
    concepts: ["health"],
    due: "2026-04-22T09:00:00",
    created: "2026-04-17T11:45:00",
    pinned: false,
    vault: false,
    done: false,
  },
  {
    id: "e4",
    type: "idea",
    title: "Short story — the woman who collected other people's dreams",
    body: "She runs a small shop. People leave their dreams on slips of paper. She catalogs them. One day she starts dreaming someone else's dream and doesn't know whose. The twist: the dream belongs to a person who died fifty years ago.",
    tags: ["writing", "fiction"],
    concepts: ["memory", "identity"],
    created: "2026-04-16T23:52:00",
    pinned: true,
    vault: false,
  },
  {
    id: "e5",
    type: "note",
    title: "Coffee with Priya — she's leaving the firm",
    body: "Going freelance. Nervous but calm-nervous, not panicked-nervous. Said the thing that finally tipped it was realizing she hadn't opened her sketchbook in four months. I should check on her in two weeks.",
    tags: ["friends", "priya"],
    concepts: ["career", "friendship"],
    created: "2026-04-15T13:20:00",
    pinned: false,
    vault: false,
  },
  {
    id: "e6",
    type: "link",
    title: "This linen jacket — Drake's, ecru",
    body: "drakes.com/products/single-breasted-jacket-ecru — too expensive. Wait for the summer markdown.",
    tags: ["wishlist"],
    concepts: ["clothing"],
    created: "2026-04-14T20:09:00",
    pinned: false,
    vault: false,
  },
  {
    id: "e7",
    type: "idea",
    title: "Maybe the whole onboarding is just one question",
    body: "What's one thing you want to not forget? Let them type it. That's the first entry. No tour. No signup of preferences. Just the act.",
    tags: ["product", "everion"],
    concepts: ["onboarding", "product-design"],
    created: "2026-04-13T09:30:00",
    pinned: false,
    vault: false,
  },
  {
    id: "e8",
    type: "reminder",
    title: "Water the olive tree",
    body: "Every 4 days in summer. Less than you think the rest of the year.",
    tags: ["home"],
    concepts: ["home"],
    due: "2026-04-23T08:00:00",
    created: "2026-04-12T18:00:00",
    pinned: false,
    vault: false,
    done: false,
  },
  {
    id: "e9",
    type: "note",
    title: "Therapy — a thing to bring up next time",
    body: "The way I apologize before asking for things. Not the content, the reflex. Where does it come from.",
    tags: ["therapy"],
    concepts: ["self", "family"],
    created: "2026-04-11T19:40:00",
    pinned: false,
    vault: true,
  },
  {
    id: "e10",
    type: "contact",
    title: "Stefan — the cabinetmaker",
    body: "Referred by Lena. He does that quiet oak work. stefan.werk@proton.me · +27 82 411 0092 · Woodstock.",
    tags: ["contacts", "craftsmen"],
    concepts: ["home"],
    created: "2026-04-10T15:10:00",
    pinned: false,
    vault: false,
  },
  {
    id: "e11",
    type: "note",
    title: "A line I want to keep",
    body: "From the Levertov — 'the authentic, the authentic.' Not sure from which poem. Find it.",
    tags: ["writing", "poetry"],
    concepts: ["poetry", "self"],
    created: "2026-04-09T07:25:00",
    pinned: false,
    vault: false,
  },
  {
    id: "e12",
    type: "idea",
    title: "A reading log that's actually a feelings log",
    body: "Track books not by progress but by what each one made me feel on that day. A single sentence per session.",
    tags: ["product", "reading"],
    concepts: ["reading", "journaling"],
    created: "2026-04-08T22:40:00",
    pinned: false,
    vault: false,
  },
  {
    id: "e13",
    type: "file",
    title: "Scan — birth certificate",
    body: "Needed for visa. Stored in vault.",
    tags: ["admin", "documents"],
    concepts: ["admin"],
    created: "2026-04-06T10:05:00",
    pinned: false,
    vault: true,
  },
  {
    id: "e14",
    type: "link",
    title: "That interview with Mary Oliver",
    body: "The one where she says paying attention is the whole job. Save before it disappears.",
    tags: ["reading", "poetry"],
    concepts: ["poetry", "attention"],
    created: "2026-04-05T11:15:00",
    pinned: false,
    vault: false,
  },
  {
    id: "e15",
    type: "reminder",
    title: "Text mom — her surgery is Thursday",
    body: "Actually call. Don't text.",
    tags: ["family"],
    concepts: ["mother", "family"],
    due: "2026-04-24T19:00:00",
    created: "2026-04-04T09:00:00",
    pinned: true,
    vault: false,
    done: false,
  },
  {
    id: "e16",
    type: "note",
    title: "The thing about good rooms",
    body: "They all have one thing that is slightly too old, slightly too quiet. Never the newest thing in the room. That's the rule.",
    tags: ["home", "ideas"],
    concepts: ["design", "home"],
    created: "2026-04-03T16:45:00",
    pinned: false,
    vault: false,
  },
];

// Concepts — the graph
const CONCEPTS = [
  { id: "c1", label: "family", weight: 8, x: 0.30, y: 0.42 },
  { id: "c2", label: "self", weight: 7, x: 0.52, y: 0.38 },
  { id: "c3", label: "memory", weight: 9, x: 0.40, y: 0.55 },
  { id: "c4", label: "writing", weight: 6, x: 0.66, y: 0.58 },
  { id: "c5", label: "poetry", weight: 5, x: 0.72, y: 0.70 },
  { id: "c6", label: "home", weight: 5, x: 0.22, y: 0.72 },
  { id: "c7", label: "dad", weight: 6, x: 0.22, y: 0.32 },
  { id: "c8", label: "mother", weight: 4, x: 0.38, y: 0.28 },
  { id: "c9", label: "reading", weight: 5, x: 0.80, y: 0.48 },
  { id: "c10", label: "attention", weight: 3, x: 0.88, y: 0.55 },
  { id: "c11", label: "grief", weight: 3, x: 0.60, y: 0.24 },
  { id: "c12", label: "identity", weight: 4, x: 0.56, y: 0.62 },
  { id: "c13", label: "friendship", weight: 4, x: 0.46, y: 0.74 },
  { id: "c14", label: "career", weight: 3, x: 0.36, y: 0.82 },
  { id: "c15", label: "onboarding", weight: 2, x: 0.78, y: 0.80 },
  { id: "c16", label: "product-design", weight: 3, x: 0.85, y: 0.86 },
  { id: "c17", label: "health", weight: 2, x: 0.14, y: 0.58 },
  { id: "c18", label: "admin", weight: 3, x: 0.12, y: 0.84 },
  { id: "c19", label: "design", weight: 3, x: 0.18, y: 0.88 },
  { id: "c20", label: "journaling", weight: 2, x: 0.70, y: 0.88 },
  { id: "c21", label: "clothing", weight: 1, x: 0.90, y: 0.30 },
  { id: "c22", label: "father", weight: 5, x: 0.15, y: 0.46 },
];

const CONCEPT_EDGES = [
  ["c1","c7"], ["c1","c8"], ["c1","c22"], ["c7","c22"], ["c1","c3"],
  ["c2","c3"], ["c2","c11"], ["c2","c12"], ["c2","c4"],
  ["c3","c12"], ["c3","c4"], ["c4","c5"], ["c4","c9"], ["c5","c9"],
  ["c9","c10"], ["c9","c5"], ["c6","c19"], ["c6","c18"], ["c13","c14"],
  ["c2","c13"], ["c15","c16"], ["c4","c20"], ["c1","c13"],
];

// Ambient toast + banner content
const NUDGES = [
  { text: "You saved three things about your dad this month. Want me to draft a letter?", action: "Draft" },
];

// Keyboard shortcut display
const isMac = typeof navigator !== 'undefined' && /Mac|iPhone|iPad/.test(navigator.platform);
const MOD = isMac ? "⌘" : "Ctrl";

// Relative time formatter
function relTime(iso) {
  const d = new Date(iso);
  const now = new Date('2026-04-21T12:00:00');
  const diff = (now - d) / 1000;
  if (diff < 60) return 'just now';
  if (diff < 3600) return Math.floor(diff/60) + 'm ago';
  if (diff < 86400) return Math.floor(diff/3600) + 'h ago';
  if (diff < 86400*7) return Math.floor(diff/86400) + 'd ago';
  return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
}

function dayLabel(iso) {
  const d = new Date(iso);
  const now = new Date('2026-04-21T12:00:00');
  const diff = Math.floor((now - d) / (86400*1000));
  if (diff === 0) return 'today';
  if (diff === 1) return 'yesterday';
  if (diff < 7) return d.toLocaleDateString('en-GB', { weekday: 'long' }).toLowerCase();
  return d.toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long' }).toLowerCase();
}

Object.assign(window, {
  BRAIN_NAME, ENTRIES, CONCEPTS, CONCEPT_EDGES, NUDGES, MOD, relTime, dayLabel
});
