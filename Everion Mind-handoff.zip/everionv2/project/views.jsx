/* Todos, Vault, Trash, Settings */

function TodosView({ openEntry }) {
  const todos = ENTRIES.filter(e => e.type === 'reminder');
  const [done, setDone] = React.useState({});
  const today = todos.filter(t => new Date(t.due) < new Date('2026-04-23'));
  const later = todos.filter(t => !today.includes(t));

  const Row = (t) => (
    <div key={t.id} onClick={() => openEntry(t)} className="card press" style={{
      padding: '14px 18px', display:'flex', alignItems:'center', gap: 14, cursor:'pointer',
      opacity: done[t.id] ? 0.5 : 1
    }}>
      <button onClick={(e) => { e.stopPropagation(); setDone(d => ({...d, [t.id]: !d[t.id]})); }}
        className="press" style={{
          width: 20, height: 20, minHeight: 20, borderRadius:'50%',
          border:'1.5px solid ' + (done[t.id] ? 'var(--ember)' : 'var(--line)'),
          background: done[t.id] ? 'var(--ember)' : 'transparent',
          display:'flex', alignItems:'center', justifyContent:'center'
        }}>
        {done[t.id] && <I.check style={{ width: 12, height: 12, color:'oklch(14% 0.03 50)' }}/>}
      </button>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div className="f-serif" style={{ fontSize: 16, fontWeight: 450, textDecoration: done[t.id] ? 'line-through' : 'none' }}>{t.title}</div>
        <div className="f-serif clip-2" style={{ fontSize: 14, color:'var(--ink-faint)', marginTop: 2, fontStyle:'italic' }}>{t.body}</div>
      </div>
      <div className="f-sans" style={{ fontSize: 12, color:'var(--ink-faint)', whiteSpace:'nowrap' }}>
        {new Date(t.due).toLocaleDateString('en-GB', { weekday:'short', day:'numeric', month:'short' }).toLowerCase()}
      </div>
    </div>
  );

  return <div style={{ height:'100%', display:'flex', flexDirection:'column' }}>
    <TopBar title="Todos" subtitle={`${todos.filter(t => !done[t.id]).length} to do`}/>
    <div className="scroll" style={{ flex: 1, padding:'28px 32px', maxWidth: 780, width:'100%', alignSelf:'center' }}>
      <Micro style={{ marginBottom: 14 }}>today & tomorrow</Micro>
      <div style={{ display:'grid', gap: 10, marginBottom: 40 }}>
        {today.map(Row)}
      </div>
      <Micro style={{ marginBottom: 14 }}>later</Micro>
      <div style={{ display:'grid', gap: 10 }}>
        {later.map(Row)}
      </div>
    </div>
  </div>;
}

function VaultView({ openEntry }) {
  const [unlocked, setUnlocked] = React.useState(false);
  const [passphrase, setPassphrase] = React.useState('');
  const [countdown, setCountdown] = React.useState(592);

  React.useEffect(() => {
    if (!unlocked) return;
    const t = setInterval(() => setCountdown(c => Math.max(0, c - 1)), 1000);
    return () => clearInterval(t);
  }, [unlocked]);

  const mins = Math.floor(countdown / 60);
  const secs = countdown % 60;

  const vaultItems = ENTRIES.filter(e => e.vault);

  if (!unlocked) return <div style={{ height:'100%', display:'flex', flexDirection:'column' }}>
    <TopBar title="Vault" subtitle="locked"/>
    <div style={{ flex: 1, display:'flex', alignItems:'center', justifyContent:'center', padding: 40, position:'relative' }}>
      <Motes count={14}/>
      <div style={{ maxWidth: 420, width:'100%', textAlign:'center', position:'relative' }}>
        <I.vault style={{ width: 40, height: 40, color:'var(--ember)', margin:'0 auto 20px' }}/>
        <h2 className="f-serif" style={{ fontSize: 32, fontWeight: 400, margin: 0, letterSpacing:'-0.01em' }}>locked.</h2>
        <p className="f-serif" style={{ fontSize: 16, color:'var(--ink-soft)', fontStyle:'italic', marginTop: 8, marginBottom: 32 }}>
          {vaultItems.length} entries, encrypted on this device. nobody else has this key.
        </p>
        <input type="password" className="input f-sans" placeholder="passphrase" autoFocus
          value={passphrase} onChange={e => setPassphrase(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && passphrase && setUnlocked(true)}
          style={{ height: 48, fontSize: 16, textAlign:'center' }}/>
        <button className="btn-primary press" style={{ width:'100%', height: 44, marginTop: 16 }}
          onClick={() => passphrase && setUnlocked(true)}>Unlock</button>
      </div>
    </div>
  </div>;

  return <div style={{ height:'100%', display:'flex', flexDirection:'column' }}>
    <TopBar title="Vault"
      subtitle={<span>unlocked for <span className="f-mono" style={{ color:'var(--ember)' }}>{mins}:{String(secs).padStart(2,'0')}</span></span>}
      right={<button className="btn-secondary press" onClick={() => setUnlocked(false)}>Lock</button>}/>
    <div className="scroll" style={{ flex: 1, padding:'24px 32px' }}>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(300px, 1fr))', gap: 16 }}>
        {vaultItems.map(e => <EntryCard key={e.id} entry={e} selected={false} onSelect={()=>{}} onOpen={openEntry} density="cozy"/>)}
      </div>
    </div>
  </div>;
}

function TrashView({ openEntry }) {
  const items = ENTRIES.slice(0, 3).map(e => ({ ...e, deleted:'2 days ago' }));
  return <div style={{ height:'100%', display:'flex', flexDirection:'column' }}>
    <TopBar title="Trash" subtitle="cleared automatically after 30 days"/>
    <div className="scroll" style={{ flex: 1, padding:'24px 32px', maxWidth: 820, alignSelf:'center', width:'100%' }}>
      <div style={{ display:'grid', gap: 12 }}>
        {items.map(e => (
          <div key={e.id} className="card" style={{ padding: 18, display:'flex', alignItems:'center', gap: 16, opacity: 0.7 }}>
            <TypeGlyph type={e.type}/>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div className="f-serif nowrap" style={{ fontSize: 15, fontWeight: 450 }}>{e.title}</div>
              <div className="f-sans" style={{ fontSize: 12, color:'var(--ink-faint)', marginTop: 2 }}>deleted {e.deleted}</div>
            </div>
            <button className="btn-secondary press" style={{ height: 32, fontSize: 13 }}><I.undo style={{ width: 12, height: 12, marginRight: 6 }}/>Restore</button>
          </div>
        ))}
      </div>
    </div>
  </div>;
}

function SettingsView() {
  const [section, setSection] = React.useState('account');
  const sections = [
    ['account','Account'],['brain','Brain'],['providers','AI providers'],
    ['notifications','Notifications'],['storage','Storage'],['integrations','Integrations'],
    ['danger','Danger zone'],
  ];
  return <div style={{ height:'100%', display:'flex', flexDirection:'column' }}>
    <TopBar title="Settings"/>
    <div style={{ flex: 1, display:'flex', overflow:'hidden' }}>
      <nav style={{ width: 220, padding:'20px 12px', borderRight:'1px solid var(--line-soft)', background:'var(--surface-low)' }}>
        {sections.map(([id, label]) => (
          <button key={id} onClick={() => setSection(id)} className="press f-sans"
            style={{
              display:'block', width:'100%', textAlign:'left',
              padding:'0 14px', minHeight: 36, height: 36, borderRadius: 6,
              fontSize: 13, fontWeight: 500,
              color: section === id ? 'var(--ink)' : 'var(--ink-soft)',
              background: section === id ? 'var(--surface)' : 'transparent',
            }}>{label}</button>
        ))}
      </nav>
      <div className="scroll" style={{ flex: 1, padding:'32px 40px', maxWidth: 720 }}>
        {section === 'account' && <SettingsAccount/>}
        {section === 'providers' && <SettingsProviders/>}
        {section === 'brain' && <SettingsBrain/>}
        {section === 'storage' && <SettingsStorage/>}
        {section === 'notifications' && <SettingsNotifications/>}
        {section === 'integrations' && <SettingsIntegrations/>}
        {section === 'danger' && <SettingsDanger/>}
      </div>
    </div>
  </div>;
}

function SettingsRow({ label, hint, children }) {
  return <div style={{ padding:'18px 0', borderBottom:'1px solid var(--line-soft)', display:'flex', justifyContent:'space-between', gap: 32, alignItems:'center' }}>
    <div style={{ flex: 1 }}>
      <div className="f-serif" style={{ fontSize: 16, fontWeight: 450 }}>{label}</div>
      {hint && <div className="f-serif" style={{ fontSize: 13, color:'var(--ink-faint)', fontStyle:'italic', marginTop: 3 }}>{hint}</div>}
    </div>
    <div>{children}</div>
  </div>;
}

function SettingsAccount() {
  return <div>
    <h2 className="f-serif" style={{ fontSize: 28, fontWeight: 450, margin: '0 0 24px', letterSpacing:'-0.01em' }}>Account</h2>
    <SettingsRow label="Email" hint="we only email you when a magic link is requested.">
      <span className="f-sans" style={{ fontSize: 14, color:'var(--ink-soft)' }}>hanno@everion.app</span>
    </SettingsRow>
    <SettingsRow label="Display name"><span className="f-sans" style={{ fontSize: 14 }}>Hanno</span></SettingsRow>
    <SettingsRow label="Sign out"><button className="btn-secondary press">Sign out</button></SettingsRow>
  </div>;
}

function SettingsProviders() {
  return <div>
    <h2 className="f-serif" style={{ fontSize: 28, fontWeight: 450, margin: '0 0 24px' }}>AI providers</h2>
    <p className="f-serif" style={{ fontSize: 15, color:'var(--ink-soft)', lineHeight: 1.55, fontStyle:'italic', marginBottom: 28 }}>
      bring your own key. routed on device. we never see the traffic.
    </p>
    {[['Anthropic','sk-ant-****5g9a','connected'],['OpenAI','','disconnected'],['Groq','gsk-****83hw','connected'],['OpenRouter','','disconnected']].map(([n, k, s]) => (
      <SettingsRow key={n} label={n} hint={s === 'connected' ? k : 'not set'}>
        <div className="row gap-2">
          <Dot color={s === 'connected' ? 'var(--moss)' : 'var(--ink-ghost)'} size={6}/>
          <button className="btn-secondary press" style={{ height: 32, fontSize: 13 }}>{s === 'connected' ? 'Rotate' : 'Add key'}</button>
        </div>
      </SettingsRow>
    ))}
  </div>;
}

function SettingsBrain() {
  return <div>
    <h2 className="f-serif" style={{ fontSize: 28, fontWeight: 450, margin: '0 0 24px' }}>Brain</h2>
    <SettingsRow label="Name"><span className="f-serif" style={{ fontSize: 15, fontStyle:'italic' }}>Hanno's brain</span></SettingsRow>
    <SettingsRow label="Concept extraction" hint="extract concepts from new entries automatically."><Toggle value={true} onChange={()=>{}}/></SettingsRow>
    <SettingsRow label="Embeddings" hint="used for semantic search. stored on device."><Toggle value={true} onChange={()=>{}}/></SettingsRow>
    <SettingsRow label="Shared brains"><button className="btn-secondary press" style={{ height: 32, fontSize: 13 }}>+ New shared brain</button></SettingsRow>
  </div>;
}

function SettingsStorage() {
  return <div>
    <h2 className="f-serif" style={{ fontSize: 28, fontWeight: 450, margin: '0 0 24px' }}>Storage</h2>
    <SettingsRow label="Entries" hint="176 entries · 2.4 MB on device"><button className="btn-secondary press" style={{ height: 32, fontSize: 13 }}>Export all</button></SettingsRow>
    <SettingsRow label="Files" hint="12 files · 34.1 MB on device"><button className="btn-secondary press" style={{ height: 32, fontSize: 13 }}>Manage</button></SettingsRow>
    <SettingsRow label="Trash" hint="3 items, auto-clearing in 28 days"><button className="btn-secondary press" style={{ height: 32, fontSize: 13 }}>Empty now</button></SettingsRow>
  </div>;
}

function SettingsNotifications() {
  const [push, setPush] = React.useState(true);
  const [nudges, setNudges] = React.useState(true);
  const [digest, setDigest] = React.useState(false);
  return <div>
    <h2 className="f-serif" style={{ fontSize: 28, fontWeight: 450, margin: '0 0 24px' }}>Notifications</h2>
    <SettingsRow label="Reminders" hint="push notifications for due reminders"><Toggle value={push} onChange={setPush}/></SettingsRow>
    <SettingsRow label="Quiet nudges" hint="when something in your memory rhymes with something new. never more than one a day."><Toggle value={nudges} onChange={setNudges}/></SettingsRow>
    <SettingsRow label="Weekly digest" hint="what you captured, what kept coming back, on sunday evenings."><Toggle value={digest} onChange={setDigest}/></SettingsRow>
  </div>;
}

function SettingsIntegrations() {
  return <div>
    <h2 className="f-serif" style={{ fontSize: 28, fontWeight: 450, margin: '0 0 24px' }}>Integrations</h2>
    <p className="f-serif" style={{ fontSize: 15, color:'var(--ink-soft)', lineHeight: 1.55, fontStyle:'italic', marginBottom: 28 }}>
      MCP and REST endpoints for the agents you already use.
    </p>
    <SettingsRow label="MCP endpoint" hint="wss://mcp.everion.app/you"><button className="btn-secondary press" style={{ height: 32, fontSize: 13 }}>Copy</button></SettingsRow>
    <SettingsRow label="REST token" hint="read-only by default"><button className="btn-secondary press" style={{ height: 32, fontSize: 13 }}>Rotate</button></SettingsRow>
    <SettingsRow label="Webhooks" hint="0 configured"><button className="btn-secondary press" style={{ height: 32, fontSize: 13 }}>+ Add</button></SettingsRow>
  </div>;
}

function SettingsDanger() {
  return <div>
    <h2 className="f-serif" style={{ fontSize: 28, fontWeight: 450, margin: '0 0 24px', color:'var(--blood)' }}>Danger zone</h2>
    <p className="f-serif" style={{ fontSize: 15, color:'var(--ink-soft)', lineHeight: 1.55, fontStyle:'italic', marginBottom: 28 }}>
      all of these are irreversible. we've made them clear, not hidden.
    </p>
    <SettingsRow label="Clear trash now"><button className="btn-secondary press" style={{ height: 32, fontSize: 13 }}>Clear</button></SettingsRow>
    <SettingsRow label="Reset concept graph" hint="we'll re-extract from all entries."><button className="btn-secondary press" style={{ height: 32, fontSize: 13 }}>Reset</button></SettingsRow>
    <SettingsRow label="Export & delete account" hint="we email you a zip of everything, then scrub you within 48 hours.">
      <button className="press f-sans" style={{ height: 32, fontSize: 13, padding:'0 14px', border:'1px solid var(--blood)', borderRadius: 8, color:'var(--blood)', background:'var(--blood-wash)' }}>Export & delete</button>
    </SettingsRow>
  </div>;
}

Object.assign(window, { TodosView, VaultView, TrashView, SettingsView });
