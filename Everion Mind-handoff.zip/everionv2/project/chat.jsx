/* Chat view — HERO MOMENT */

function ChatView({ openEntry, mobile }) {
  const [messages, setMessages] = React.useState([
    { role:'user', text:"what did i save about my dad this year?" },
    { role:'tool', summary:'Searched entries · dad, father, family · 4 results', expanded: false, results:[
      { id:'e1', title:"What dad said on Sunday" },
      { id:'e9', title:"Therapy — a thing to bring up next time" },
      { id:'e15', title:"Text mom — her surgery is Thursday" },
      { id:'e22', title:"An old letter — dad to oma, 1987" },
    ]},
    { role:'assistant', text:`Four things this year, and they rhyme more than you might think.\n\nThere's the Sunday coffee¹ — the one where he told you he was proud of you, and you asked if he wanted milk. That's the one you wrote you want to remember.\n\nIn therapy² you've been noticing the way you apologize before asking for things, and asking where that comes from. You didn't name him in the entry, but the concept graph puts it under "father."\n\nThere's your mother's surgery³ coming up Thursday — you wrote "actually call. don't text." That's another entry about him, sideways.\n\nI'd say the through-line is: you're paying closer attention to them right now than you have been.`,
      citations:[
        { n:1, id:'e1', title:"What dad said on Sunday" },
        { n:2, id:'e9', title:"Therapy — a thing to bring up next time" },
        { n:3, id:'e15', title:"Text mom — her surgery is Thursday" },
      ] },
  ]);
  const [input, setInput] = React.useState('');
  const [streaming, setStreaming] = React.useState(false);
  const [showCitation, setShowCitation] = React.useState(null);
  const scrollRef = React.useRef(null);

  const send = () => {
    if (!input.trim()) return;
    const q = input;
    setMessages(m => [...m, { role:'user', text: q }]);
    setInput('');
    setStreaming(true);
    setTimeout(() => {
      setMessages(m => [...m,
        { role:'tool', summary:`Searched entries · ${q.split(' ').slice(0,2).join(', ').toLowerCase()} · 3 results`, expanded:false },
        { role:'assistant', text:"Let me think about that for a moment.\n\nI found a few threads that touch what you're asking. The clearest one is from last Tuesday¹ — it was brief but specific.", citations:[{ n:1, id:'e5', title:"Coffee with Priya — she's leaving the firm" }] }
      ]);
      setStreaming(false);
    }, 1400);
  };

  const toggleTool = (i) => setMessages(m => m.map((msg, idx) => idx === i ? { ...msg, expanded: !msg.expanded } : msg));

  return <div style={{ height:'100%', display:'flex', flexDirection:'column' }}>
    {!mobile && <TopBar title="Chat" subtitle="a conversation with your memory"/>}

    <div className="scroll" ref={scrollRef} style={{ flex: 1, padding: mobile ? '20px 16px 16px' : '32px 48px', maxWidth: 820, width:'100%', margin:'0 auto', alignSelf:'center' }}>
      {messages.map((m, i) => (
        <div key={i} className="anim-fade-up" style={{ marginBottom: 28, animationDelay: i * 30 + 'ms' }}>
          {m.role === 'user' && (
            <div style={{ display:'flex', justifyContent:'flex-end' }}>
              <div className="f-sans" style={{
                background:'var(--surface-high)', border:'1px solid var(--line-soft)',
                padding:'12px 18px', borderRadius: 18, maxWidth:'70%',
                fontSize: 15, lineHeight: 1.5, color:'var(--ink)'
              }}>{m.text}</div>
            </div>
          )}
          {m.role === 'tool' && (
            <button onClick={() => toggleTool(i)} className="press f-sans" style={{
              display:'flex', alignItems:'center', gap: 10,
              padding:'8px 14px', minHeight: 32, height: 32,
              border:'1px solid var(--line-soft)', borderRadius: 999,
              background:'var(--surface-low)', color:'var(--ink-faint)', fontSize: 12,
            }}>
              <I.search style={{ width: 12, height: 12 }}/>
              {m.summary}
              <span style={{ opacity: 0.5, marginLeft: 2 }}>{m.expanded ? '▾' : '▸'}</span>
            </button>
          )}
          {m.role === 'tool' && m.expanded && m.results && (
            <div className="anim-fade-up" style={{ marginTop: 10, marginLeft: 12, padding:'10px 16px', borderLeft:'2px solid var(--line-soft)' }}>
              {m.results.map(r => (
                <div key={r.id} className="f-serif" style={{ fontSize: 14, padding:'4px 0', color:'var(--ink-soft)' }}>→ {r.title}</div>
              ))}
            </div>
          )}
          {m.role === 'assistant' && (
            <div>
              <div className="f-serif" style={{
                fontSize: mobile ? 17 : 18, lineHeight: 1.65, color:'var(--ink)',
                whiteSpace:'pre-wrap',
              }}>
                {m.text.split(/(\¹|\²|\³|\⁴|\⁵)/).map((part, k) => {
                  if (/[¹²³⁴⁵]/.test(part)) {
                    const n = '¹²³⁴⁵'.indexOf(part) + 1;
                    const cite = m.citations?.find(c => c.n === n);
                    return <button key={k} onClick={() => setShowCitation(cite)} className="press"
                      style={{ color:'var(--ember)', fontSize: '0.75em', verticalAlign: 'super', padding: 0, minHeight: 0, margin:'0 1px' }}>{part}</button>;
                  }
                  return part;
                })}
              </div>
              {m.citations && (
                <div className="row gap-2" style={{ marginTop: 16, flexWrap:'wrap' }}>
                  {m.citations.map(c => (
                    <button key={c.n} onClick={() => setShowCitation(c)} className="press f-sans" style={{
                      display:'flex', alignItems:'center', gap: 8,
                      padding:'6px 12px', minHeight: 28, height: 28,
                      border:'1px solid var(--line-soft)', borderRadius: 6,
                      background:'var(--surface)', fontSize: 12, color:'var(--ink-soft)',
                    }}>
                      <span style={{ color:'var(--ember)', fontWeight: 600 }}>{c.n}</span>
                      <span className="f-serif" style={{ fontStyle:'italic' }}>{c.title}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      ))}
      {streaming && (
        <div className="row gap-2" style={{ padding: '8px 4px' }}>
          <Dot color="var(--ember)" size={8} breathe/>
          <SerifWhisper>thinking…</SerifWhisper>
        </div>
      )}
      {messages.length === 0 && (
        <div style={{ textAlign:'center', padding:'80px 20px' }}>
          <p className="f-serif" style={{ fontSize: 22, fontStyle:'italic', color:'var(--ink-soft)' }}>
            Ask me anything about what you've written down.
          </p>
        </div>
      )}
    </div>

    {/* Composer */}
    <div style={{
      padding: mobile ? '12px 16px calc(12px + env(safe-area-inset-bottom, 0px))' : '16px 48px 24px',
      borderTop:'1px solid var(--line-soft)', background:'var(--bg)'
    }}>
      <div style={{
        maxWidth: 820, margin:'0 auto',
        background:'var(--surface)', border:'1px solid var(--line)',
        borderRadius: 18, padding: '10px 14px',
        display:'flex', alignItems:'flex-end', gap: 10,
      }}>
        <textarea value={input} onChange={e => setInput(e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } }}
          placeholder="ask your memory…" className="f-serif" style={{
          flex: 1, resize:'none', fontSize: 16, lineHeight: 1.5, minHeight: 24, maxHeight: 140, padding:'6px 0',
          color:'var(--ink)', fontStyle: input ? 'normal' : 'italic'
        }} rows={1}/>
        <button className="btn-ghost press" style={{ padding: 8, minHeight: 36 }}><I.mic style={{ width: 16, height: 16 }}/></button>
        <button onClick={send} disabled={!input.trim()} className="press"
          style={{
            width: 36, height: 36, minHeight: 36, borderRadius: 8,
            background: input.trim() ? 'var(--ember)' : 'var(--surface-high)',
            color: input.trim() ? 'oklch(14% 0.03 50)' : 'var(--ink-faint)',
            display:'flex', alignItems:'center', justifyContent:'center',
            transition: 'background 180ms'
          }}>
          <I.send style={{ width: 14, height: 14 }}/>
        </button>
      </div>
    </div>

    {showCitation && <CitationPreview cite={showCitation} onClose={() => setShowCitation(null)} onOpen={openEntry}/>}
  </div>;
}

function CitationPreview({ cite, onClose, onOpen }) {
  const entry = ENTRIES.find(e => e.id === cite.id);
  if (!entry) return null;
  return <Scrim onClick={onClose}>
    <div onClick={e => e.stopPropagation()} className="anim-scale-in" style={{
      background:'var(--surface-high)', border:'1px solid var(--line)', borderRadius: 18,
      maxWidth: 520, width:'92vw', padding: 28, boxShadow:'var(--lift-3)'
    }}>
      <div className="row gap-2" style={{ marginBottom: 12, color:'var(--ink-faint)' }}>
        <span className="f-sans" style={{ color:'var(--ember)', fontWeight: 600 }}>{cite.n}</span>
        <TypeGlyph type={entry.type}/><span className="f-sans" style={{ fontSize: 12, textTransform:'uppercase', letterSpacing:'0.04em' }}>{entry.type}</span>
        <span className="f-sans" style={{ fontSize: 12, marginLeft: 'auto' }}>{relTime(entry.created)}</span>
      </div>
      <h3 className="f-serif" style={{ fontSize: 24, fontWeight: 450, lineHeight: 1.25, margin: 0 }}>{entry.title}</h3>
      <p className="f-serif" style={{ fontSize: 16, lineHeight: 1.6, color:'var(--ink-soft)', marginTop: 14 }}>{entry.body}</p>
      <div className="row gap-2" style={{ marginTop: 20, justifyContent:'flex-end' }}>
        <button className="btn-secondary press" onClick={onClose}>Close</button>
        <button className="btn-primary press" onClick={() => { onOpen?.(entry); onClose(); }}>Open entry →</button>
      </div>
    </div>
  </Scrim>;
}

Object.assign(window, { ChatView });
