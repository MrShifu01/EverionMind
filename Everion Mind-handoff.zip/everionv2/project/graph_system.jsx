/* Graph — constellations + Omnisearch + System surfaces */

function GraphView({ motion, openEntry }) {
  const [hover, setHover] = React.useState(null);
  const [sel, setSel] = React.useState(null);
  const [zoom, setZoom] = React.useState(1);

  const size = 800;

  return <div style={{ height:'100%', display:'flex', flexDirection:'column', position:'relative' }}>
    <TopBar title="Graph" subtitle="the shape of what you've been writing about"/>
    <div style={{ flex: 1, display:'flex', overflow:'hidden' }}>
      <div style={{ flex: 1, position:'relative', background:'var(--surface-dim)', overflow:'hidden' }}>
        <Motes count={50}/>
        {/* soft halo */}
        <div style={{ position:'absolute', top:'50%', left:'50%', transform:'translate(-50%,-50%)', width: 600, height: 600, borderRadius:'50%', background:'radial-gradient(circle, var(--ember-wash) 0%, transparent 70%)', opacity: 0.4, pointerEvents:'none' }}/>

        <svg viewBox="0 0 1 1" preserveAspectRatio="xMidYMid meet" style={{ position:'absolute', inset: 0, width:'100%', height:'100%' }}>
          {/* edges */}
          {CONCEPT_EDGES.map(([a, b], i) => {
            const A = CONCEPTS.find(c => c.id === a), B = CONCEPTS.find(c => c.id === b);
            if (!A || !B) return null;
            const active = hover && (hover.id === a || hover.id === b) || sel && (sel.id === a || sel.id === b);
            return <line key={i} x1={A.x} y1={A.y} x2={B.x} y2={B.y}
              stroke={active ? 'var(--ember)' : 'var(--ink-ghost)'}
              strokeWidth={active ? 0.0012 : 0.0006}
              opacity={active ? 0.5 : 0.18}
              style={{ transition:'all 260ms' }}/>;
          })}
          {/* stars */}
          {CONCEPTS.map(c => {
            const r = 0.003 + c.weight * 0.00085;
            const active = hover?.id === c.id || sel?.id === c.id;
            return <g key={c.id} onMouseEnter={() => setHover(c)} onMouseLeave={() => setHover(null)}
              onClick={() => setSel(c)} style={{ cursor:'pointer' }}>
              <circle cx={c.x} cy={c.y} r={r * 3.5} fill="var(--ember)" opacity={active ? 0.22 : 0}
                style={{ transition:'opacity 260ms' }}/>
              <circle cx={c.x} cy={c.y} r={r} fill={active ? 'var(--ember)' : 'var(--ink)'}
                opacity={active ? 1 : (0.35 + c.weight * 0.06)}
                style={{ transition:'all 260ms', animation: motion === 'off' ? 'none' : `breathe ${6 + (c.weight % 4)}s ease-in-out infinite`,
                  '--b-low': 0.35 + c.weight * 0.04, '--b-high': 0.5 + c.weight * 0.06 }}/>
            </g>;
          })}
        </svg>

        {/* labels on hover */}
        {CONCEPTS.map(c => {
          const active = hover?.id === c.id || sel?.id === c.id;
          if (!active) return null;
          return <div key={c.id} className="f-serif" style={{
            position:'absolute', left: `calc(${c.x * 100}% + 10px)`, top: `calc(${c.y * 100}% + 8px)`,
            fontSize: 15, fontStyle:'italic', color:'var(--ember)',
            pointerEvents:'none', textShadow:'0 1px 4px var(--bg)'
          }}>{c.label}</div>;
        })}

        {/* prominent label for big concepts */}
        {CONCEPTS.filter(c => c.weight >= 7).map(c => hover?.id !== c.id && sel?.id !== c.id ? (
          <div key={'L-'+c.id} className="f-serif" style={{
            position:'absolute', left: `calc(${c.x * 100}% + 10px)`, top: `calc(${c.y * 100}% + 8px)`,
            fontSize: 13, color:'var(--ink-faint)', pointerEvents:'none',
            fontStyle:'italic', opacity: 0.7,
          }}>{c.label}</div>
        ) : null)}

        {/* corner legend */}
        <div style={{ position:'absolute', bottom: 20, left: 20 }} className="f-serif">
          <div style={{ fontSize: 13, fontStyle:'italic', color:'var(--ink-faint)' }}>
            {CONCEPTS.length} concepts · {CONCEPT_EDGES.length} threads
          </div>
        </div>
        <div className="row gap-1" style={{ position:'absolute', bottom: 20, right: 20 }}>
          <button className="btn-ghost press" style={{ padding: 8, minHeight: 32 }} onClick={() => setZoom(z => Math.max(0.5, z - 0.25))}>–</button>
          <button className="btn-ghost press" style={{ padding: 8, minHeight: 32 }} onClick={() => setZoom(z => Math.min(2.5, z + 0.25))}>+</button>
        </div>
      </div>

      {/* rail */}
      {sel && <aside style={{ width: 360, borderLeft:'1px solid var(--line-soft)', padding: 28, background:'var(--surface)', overflow:'auto' }}>
        <button className="btn-ghost press" onClick={() => setSel(null)} style={{ padding: 6, minHeight: 30, marginBottom: 12 }}><I.x style={{ width: 14, height: 14 }}/></button>
        <Micro style={{ marginBottom: 8 }}>concept</Micro>
        <h2 className="f-serif" style={{ fontSize: 36, fontWeight: 400, fontStyle:'italic', letterSpacing:'-0.015em', margin: 0 }}>{sel.label}</h2>
        <div className="f-serif" style={{ fontSize: 14, color:'var(--ink-faint)', marginTop: 8, fontStyle:'italic' }}>
          appears in {sel.weight} entries · brightest when {sel.weight > 6 ? 'you write often' : 'it co-occurs with family'}
        </div>
        <Micro style={{ marginTop: 28, marginBottom: 12 }}>entries</Micro>
        <div style={{ display:'grid', gap: 10 }}>
          {ENTRIES.filter(e => e.concepts?.includes(sel.label)).slice(0, 5).map(e => (
            <div key={e.id} onClick={() => openEntry(e)} className="press" style={{ borderLeft:'2px solid var(--line)', paddingLeft: 14, cursor:'pointer' }}>
              <div className="f-serif" style={{ fontSize: 15, fontWeight: 450 }}>{e.title}</div>
              <div className="f-serif clip-2" style={{ fontSize: 13, color:'var(--ink-faint)', marginTop: 2 }}>{e.body}</div>
            </div>
          ))}
        </div>
      </aside>}
    </div>
  </div>;
}

function OmniSearch({ onClose, go, openEntry }) {
  const [q, setQ] = React.useState('');
  const entries = ENTRIES.filter(e => (e.title + e.body).toLowerCase().includes(q.toLowerCase())).slice(0, 4);
  const concepts = CONCEPTS.filter(c => c.label.includes(q.toLowerCase())).slice(0, 3);
  const commands = [
    { label: 'Remember something', go: 'capture', kbd: ['N'] },
    { label: 'Go to chat', go: 'chat', kbd: ['J'] },
    { label: 'Go to graph', go: 'graph', kbd: ['G'] },
    { label: 'Toggle theme', go: null, kbd: ['T'] },
  ].filter(c => !q || c.label.toLowerCase().includes(q.toLowerCase()));

  return <Scrim onClick={onClose} style={{ alignItems:'flex-start', paddingTop: '12vh' }}>
    <div onClick={e => e.stopPropagation()} className="anim-scale-in" style={{
      width: 640, maxWidth:'92vw', background:'var(--surface-high)', border:'1px solid var(--line)',
      borderRadius: 18, boxShadow:'var(--lift-3)', overflow:'hidden',
    }}>
      <div className="row gap-3" style={{ padding:'18px 20px', borderBottom:'1px solid var(--line-soft)' }}>
        <I.search style={{ width: 18, height: 18, color:'var(--ink-faint)' }}/>
        <input className="f-serif" autoFocus placeholder="search everything…" value={q} onChange={e => setQ(e.target.value)}
          style={{ flex: 1, fontSize: 17, fontStyle: q ? 'normal' : 'italic', color:'var(--ink)' }}/>
        <Kbd>esc</Kbd>
      </div>
      <div className="scroll" style={{ maxHeight: 480 }}>
        {entries.length > 0 && <>
          <Micro style={{ padding:'14px 20px 6px' }}>entries</Micro>
          {entries.map(e => (
            <button key={e.id} onClick={() => { openEntry(e); onClose(); }} className="press"
              style={{ display:'flex', width:'100%', padding:'10px 20px', gap: 12, textAlign:'left', alignItems:'center', minHeight: 44 }}>
              <TypeGlyph type={e.type}/>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div className="f-serif nowrap" style={{ fontSize: 15, fontWeight: 450 }}>{e.title}</div>
                <div className="f-serif nowrap" style={{ fontSize: 12, color:'var(--ink-faint)', fontStyle:'italic' }}>{e.tags.join(' · ')}</div>
              </div>
            </button>
          ))}
        </>}
        {concepts.length > 0 && <>
          <Micro style={{ padding:'14px 20px 6px' }}>concepts</Micro>
          {concepts.map(c => (
            <button key={c.id} onClick={() => { go('graph'); onClose(); }} className="press"
              style={{ display:'flex', width:'100%', padding:'10px 20px', gap: 12, textAlign:'left', alignItems:'center', minHeight: 40 }}>
              <Dot color="var(--ember)" size={5}/>
              <span className="f-serif" style={{ fontSize: 15, fontStyle:'italic' }}>{c.label}</span>
              <span className="f-sans" style={{ fontSize: 11, color:'var(--ink-faint)', marginLeft: 8 }}>{c.weight} entries</span>
            </button>
          ))}
        </>}
        {commands.length > 0 && <>
          <Micro style={{ padding:'14px 20px 6px' }}>commands</Micro>
          {commands.map(c => (
            <button key={c.label} onClick={() => { c.go && go(c.go); onClose(); }} className="press"
              style={{ display:'flex', width:'100%', padding:'10px 20px', gap: 12, textAlign:'left', alignItems:'center', justifyContent:'space-between', minHeight: 40 }}>
              <span className="f-sans" style={{ fontSize: 14 }}>{c.label}</span>
              <div className="row gap-1"><Kbd>{window.MOD}</Kbd>{c.kbd.map(k => <Kbd key={k}>{k}</Kbd>)}</div>
            </button>
          ))}
        </>}
        {entries.length + concepts.length + commands.length === 0 && (
          <div className="f-serif" style={{ padding: 32, textAlign:'center', fontSize: 15, color:'var(--ink-faint)', fontStyle:'italic' }}>
            nothing here yet. try a looser word.
          </div>
        )}
      </div>
    </div>
  </Scrim>;
}

function ConsentBanner({ onAccept }) {
  return <div className="anim-fade-up" style={{
    position:'fixed', bottom: 16, left: 16, right: 16, maxWidth: 520,
    background:'var(--surface-high)', border:'1px solid var(--line)', borderRadius: 12,
    padding: 18, boxShadow:'var(--lift-2)', zIndex: 50,
    display:'flex', gap: 14, alignItems:'center'
  }}>
    <p className="f-serif" style={{ flex: 1, fontSize: 14, lineHeight: 1.5, margin: 0, fontStyle:'italic', color:'var(--ink-soft)' }}>
      we use one cookie to remember this banner. that's all. nothing tracks you.
    </p>
    <button className="btn-primary press" style={{ height: 34, fontSize: 13 }} onClick={onAccept}>ok</button>
  </div>;
}

function UndoToast({ text = 'entry moved to trash', onUndo, onDismiss }) {
  return <div className="anim-fade-up" style={{
    position:'fixed', bottom: 24, left:'50%', transform:'translateX(-50%)',
    background:'var(--surface-high)', border:'1px solid var(--line)', borderRadius: 999,
    padding:'10px 10px 10px 18px', display:'flex', alignItems:'center', gap: 14,
    boxShadow:'var(--lift-2)', zIndex: 45,
  }}>
    <span className="f-serif" style={{ fontSize: 14, fontStyle:'italic' }}>{text}</span>
    <button onClick={onUndo} className="press f-sans" style={{ color:'var(--ember)', fontWeight: 500, padding:'6px 12px', minHeight: 28 }}>undo</button>
    <button onClick={onDismiss} className="btn-ghost press" style={{ padding: 6, minHeight: 28 }}><I.x style={{ width: 12, height: 12 }}/></button>
  </div>;
}

function EarlyAccessBanner({ onClose }) {
  return <div className="row" style={{
    padding:'8px 20px', background:'var(--ember-wash)', borderBottom:'1px solid var(--ember)',
    justifyContent:'center', gap: 12, fontSize: 13,
  }}>
    <Dot color="var(--ember)" size={5} breathe/>
    <span className="f-serif" style={{ fontStyle:'italic', color:'var(--ember)' }}>early access — you're part of the first 200. things will move.</span>
    <button onClick={onClose} className="press" style={{ padding: 4, minHeight: 20 }}><I.x style={{ width: 12, height: 12 }}/></button>
  </div>;
}

function NudgeBanner({ onDismiss }) {
  return <div className="anim-fade-up" style={{
    background:'var(--surface)', border:'1px solid var(--line-soft)', borderRadius: 12,
    padding:'14px 18px', display:'flex', gap: 14, alignItems:'center',
    margin:'0 32px 20px',
  }}>
    <I.sparkle style={{ width: 18, height: 18, color:'var(--ember)', flexShrink: 0 }}/>
    <div className="f-serif" style={{ flex: 1, fontSize: 14, lineHeight: 1.5, fontStyle:'italic' }}>
      you've saved three things about your dad this month. want me to draft a letter?
    </div>
    <button className="btn-secondary press" style={{ height: 30, fontSize: 12 }}>draft</button>
    <button onClick={onDismiss} className="btn-ghost press" style={{ padding: 6, minHeight: 28 }}><I.x style={{ width: 12, height: 12 }}/></button>
  </div>;
}

Object.assign(window, { GraphView, OmniSearch, ConsentBanner, UndoToast, EarlyAccessBanner, NudgeBanner });
